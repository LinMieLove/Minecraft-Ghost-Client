package Space;

import org.lwjgl.input.*;

public class BenCore
{
    public static int getKeyIndex(final String arg) {
        return Keyboard.getKeyIndex(arg);
    }
    
    public static String getKeyName(final int key) {
        return Keyboard.getKeyName(key);
    }
    
    public static boolean getEventKeyState() {
        return Keyboard.getEventKeyState();
    }
    
    public static int getEventKey() {
        return Keyboard.getEventKey();
    }
}
