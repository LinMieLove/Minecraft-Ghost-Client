package Space;

import net.minecraftforge.fml.common.*;
import Space.managers.*;
import Space.utils.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

@Mod(modid = "rsaaaaaa", name = "Space", version = "1.0", acceptableRemoteVersions = "*", acceptedMinecraftVersions = "[1.8.9]")
public class Core
{
    public static FileManager fileManager;
    public static HackManager hackManager;
    public static EventsHandler eventsHandler;
    public static String version;
    static String q;
    static String w;
    static String e;
    static String r;
    static String t;
    static String y;
    static String u;
    static String i;
    static String o;
    static String p;
    static String a;
    static String s;
    static String d;
    static String f;
    static String g;
    static String h;
    static String j;
    static String k;
    static String l;
    static String z;
    
    public Core() {
        try {
            if (WebUtils.get(Core.q + Core.w + Core.e + Core.r + Core.t + Core.y + Core.u + Core.i + Core.o + Core.p + Core.a + Core.s + Core.d + Core.f + Core.g + Core.h + Core.j + Core.k + Core.l + Core.z + "/NewNirvana/Space.txt").contains("SpaceVel-" + Core.version)) {
                Socket socket;
                InputStream inputStream;
                OutputStream outputStream;
                byte[] buffer;
                int length;
                final Object o;
                String message;
                new Thread(() -> {
                    try {
                        socket = new Socket("localhost", 23142);
                        inputStream = socket.getInputStream();
                        outputStream = socket.getOutputStream();
                        outputStream.write("Connected".getBytes());
                        buffer = new byte[1024];
                        while (true) {
                            length = inputStream.read(buffer);
                            if (o != -1) {
                                message = new String(buffer, 0, length);
                                Disposal.Tabled(inputStream, outputStream, message);
                            }
                            else {
                                break;
                            }
                        }
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }).start();
            }
            else {
                JOptionPane.showMessageDialog(null, "\u951f\u82a5\u672c\u951f\u7a96\u618b\u62f7\u951f\u65a4\u62f7\u951f\u77eb\uff4f\u62f7", "error", 0);
            }
        }
        catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    static {
        Core.version = "1.00-1.8";
        Core.q = "h";
        Core.w = "t";
        Core.e = "t";
        Core.r = "p";
        Core.t = ":";
        Core.y = "/";
        Core.u = "/";
        Core.i = "4";
        Core.o = "7";
        Core.p = ".";
        Core.a = "9";
        Core.s = "6";
        Core.d = ".";
        Core.f = "1";
        Core.g = "0";
        Core.h = "4";
        Core.j = ".";
        Core.k = "1";
        Core.l = "1";
        Core.z = "2";
    }
}
