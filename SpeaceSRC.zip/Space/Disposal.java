package Space;

import Space.managers.*;
import Space.hack.*;
import java.lang.management.*;
import Space.hack.hacks.Visual.UI.*;
import net.minecraft.client.gui.*;
import java.util.*;
import Space.value.*;
import net.minecraftforge.common.*;
import Space.utils.*;
import net.minecraftforge.fml.common.*;
import java.io.*;

public class Disposal
{
    private static OutputStream outputStream;
    public static String message;
    private static String SendX_;
    
    public static void Tabled(final InputStream e, final OutputStream a, String v) {
        Disposal.outputStream = a;
        Disposal.message = v;
        if (v.equals("initialize")) {
            initialize();
        }
        else if (v.equals("addHacks")) {
            HackManager.addHacks();
            Send30(HackManager.Feature);
        }
        else if (v.equals("FileManager")) {
            Core.fileManager = new FileManager();
            Send60("All executions are complete");
        }
        else if (v.contains("Next ")) {
            v = v.replace("Next ", "");
            final String temp = HackManager.OK;
            HackManager.OK = temp + v;
            HackManager.addHacks();
        }
        else if (v.contains("Toggle ")) {
            v = v.replace("Toggle ", "");
            HackManager.getHack(v).toggle();
        }
        else if (v.contains("Ui ")) {
            v = v.replace("Ui ", "");
            for (final Hack h : HackManager.getHacks()) {
                if (h.getName().equals(v)) {
                    for (final Value x : h.getValues()) {
                        if (x instanceof BooleanValue) {
                            Send150("BooleanValue" + x.getName() + ":" + x.getValue());
                        }
                        if (x instanceof NumberValue) {
                            Send150("NumberValue" + x.getName() + ":" + x.getValue() + "[\"" + ((NumberValue)x).getMin() + "\"-\"" + ((NumberValue)x).getMax() + "\"]");
                        }
                        if (x instanceof ModeValue) {
                            final ModeValue modeValue = (ModeValue)x;
                            for (final Mode modeS : modeValue.getModes()) {
                                if (modeS.isToggled()) {
                                    Send150("ModeValue" + x.getName() + ":" + modeS.getName());
                                }
                            }
                        }
                    }
                }
            }
            Send150("UIALLInfo");
        }
        else if (v.contains("ModeInfo ")) {
            final String[] parts = v.split("\\s+");
            final String Name = parts[1];
            final String Value = parts[2];
            for (final Hack h2 : HackManager.getHacks()) {
                if (h2.getName().equals(Name)) {
                    for (final Value x2 : h2.getValues()) {
                        if (x2 instanceof ModeValue) {
                            final ModeValue modeValue2 = (ModeValue)x2;
                            for (final Mode modeS2 : modeValue2.getModes()) {
                                if (Value.equals(x2.getName())) {
                                    Send150("ModeInfo:" + modeS2.getName());
                                }
                            }
                        }
                    }
                }
            }
            Send150("ModeALLInfo");
        }
        else if (v.contains("#")) {
            final String[] parts = v.split("\\s+");
            final String Name = parts[0].substring(1);
            final String Mode = parts[1];
            final String value = parts[2];
            HackManager.getHack(Name).setModes(Mode, value);
            Send60("[All Modes have been committed]");
        }
        else if (v.contains("!GEY ")) {
            v = v.replace("!GEY ", "");
            Send60("[Key-" + String.valueOf(HackManager.getHack(v).getKey()) + "]");
        }
        else if (v.contains("!KEY ")) {
            final String[] parts = v.split("\\s+");
            final String Name = parts[1];
            final String Key = parts[2];
            for (final Hack h2 : HackManager.getHacks()) {
                if (h2.getName().equals(Name)) {
                    h2.setKey(Integer.parseInt(Key));
                }
            }
            Send60("[Key-" + Key + "]");
        }
        else if (v.contains("!KEY2 ")) {
            final String[] parts = v.split("\\s+");
            final String Name = parts[1];
            final String Key = parts[2];
            for (final Hack h2 : HackManager.getHacks()) {
                if (h2.getName().equals(Name)) {
                    h2.setKey(BenCore.getKeyIndex(Key));
                }
            }
            Send60("[Key-" + String.valueOf(BenCore.getKeyIndex(Key)) + "]");
        }
        else if (v.equals("Reload")) {
            FileManager.loadHacks();
        }
        else if (v.equals("Pid")) {
            final String processName = ManagementFactory.getRuntimeMXBean().getName();
            final long pid = Long.parseLong(processName.split("@")[0]);
            Send30("Pid[" + pid + "]");
        }
        else if (v.equals("HudSettings")) {
            Wrapper.mc().func_147108_a((GuiScreen)new GuiCustomScreen());
        }
    }
    
    private static void initialize() {
        Core.hackManager = new HackManager();
        Core.eventsHandler = new EventsHandler();
        Nan0EventRegister.register(MinecraftForge.EVENT_BUS, Core.eventsHandler);
        Nan0EventRegister.register(FMLCommonHandler.instance().bus(), Core.eventsHandler);
    }
    
    public static void Send60(final String v) {
        try {
            Thread.sleep(60L);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            Disposal.outputStream.write(v.getBytes());
        }
        catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }
    
    public static void Send30(final String v) {
        try {
            Thread.sleep(30L);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            Disposal.outputStream.write(v.getBytes());
        }
        catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }
    
    public static void Send100(final String v) {
        try {
            Thread.sleep(100L);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            Disposal.outputStream.write(v.getBytes());
        }
        catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }
    
    public static void Send150(final String v) {
        try {
            Thread.sleep(150L);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            Disposal.outputStream.write(v.getBytes());
        }
        catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }
    
    public static void Send0(final String v) {
        try {
            Disposal.outputStream.write(v.getBytes());
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void SendX(final String v) {
        if (Disposal.SendX_.equals(v)) {
            return;
        }
        try {
            Thread.sleep(200L);
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            Disposal.SendX_ = v;
            final String text = "@X[" + v + "]";
            Disposal.outputStream.write(text.getBytes());
        }
        catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }
    
    static {
        Disposal.SendX_ = "";
    }
}
