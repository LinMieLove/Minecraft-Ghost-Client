package Space;

import net.minecraft.client.multiplayer.*;
import Space.managers.*;
import Space.hack.*;
import java.util.*;
import net.minecraftforge.fml.common.eventhandler.*;
import Space.utils.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.client.event.*;

public class EventsHandler
{
    private boolean initialized;
    public String map;
    public WorldClient upworld;
    
    public EventsHandler() {
        this.initialized = false;
        this.map = "";
        this.upworld = null;
    }
    
    @SubscribeEvent
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            final int key = BenCore.getEventKey();
            if (key == 0 || key == -1) {
                return;
            }
            if (BenCore.getEventKeyState()) {
                for (final Hack hack : HackManager.getHacks()) {
                    if (hack.getKey() == key) {
                        hack.toggle();
                    }
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public boolean onPacket(final Object packet, final Connection.Side side) {
        boolean suc = true;
        for (final Hack hack : HackManager.getHacks()) {
            if (hack.isToggled()) {
                if (Wrapper.world() == null) {
                    continue;
                }
                suc &= hack.onPacket(packet, side);
            }
        }
        return suc;
    }
    
    @SubscribeEvent
    public void onCameraSetup(final EntityViewRenderEvent.CameraSetup event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onCameraSetup(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Utils.nullCheck()) {
            this.initialized = false;
            return;
        }
        try {
            if (!this.initialized) {
                new Connection(this);
                this.initialized = true;
            }
            if (!Wrapper.world().equals(this.upworld)) {
                this.upworld = Wrapper.world();
                this.map = "";
            }
            HackManager.onClientTick(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onLeftClickBlock(final PlayerInteractEvent event) {
        final PlayerInteractEvent.Action action = event.action;
        final PlayerInteractEvent.Action action2 = event.action;
        if (action != PlayerInteractEvent.Action.LEFT_CLICK_BLOCK || event.isCanceled()) {
            return;
        }
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onLeftClickBlock(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onRightClickItem(final PlayerInteractEvent event) {
        final PlayerInteractEvent.Action action = event.action;
        final PlayerInteractEvent.Action action2 = event.action;
        if (action != PlayerInteractEvent.Action.RIGHT_CLICK_AIR) {
            final PlayerInteractEvent.Action action3 = event.action;
            final PlayerInteractEvent.Action action4 = event.action;
            if (action3 != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) {
                return;
            }
        }
        if (!event.isCanceled()) {
            if (Utils.nullCheck()) {
                return;
            }
            try {
                HackManager.onRightClickItem(event);
            }
            catch (RuntimeException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    @SubscribeEvent
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onRenderGameOverlay(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onMouse(final MouseEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onMouse(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onAttackEntity(final AttackEntityEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onAttackEntity(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onInputUpdateEvent(final TickEvent.PlayerTickEvent event) {
        final TickEvent.Phase phase = event.phase;
        final TickEvent.Phase phase2 = event.phase;
        if (phase != TickEvent.Phase.START || Utils.nullCheck() || event.player != Wrapper.player()) {
            return;
        }
        try {
            HackManager.onInputUpdate(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onLivingUpdate(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onPlayerMove(final LivingEvent.LivingUpdateEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onPlayerMove(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (Utils.nullCheck() || Wrapper.mc().field_71474_y.field_74319_N) {
            return;
        }
        try {
            HackManager.onRenderWorldLast(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onPlayerTick(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onRender3D(final RenderBlockOverlayEvent event) {
        if (Wrapper.mc().field_71474_y.field_74319_N) {
            return;
        }
        try {
            HackManager.onRender3D(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
}
