package Space.hack;

public class End extends Hack
{
    public End() {
        super("End", HackCategory.Visual);
    }
}
