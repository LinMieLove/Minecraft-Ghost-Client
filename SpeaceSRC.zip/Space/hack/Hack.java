package Space.hack;

import Space.managers.*;
import Space.*;
import java.util.*;
import Space.value.*;
import Space.utils.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.client.event.*;

public class Hack
{
    private boolean Default;
    private boolean Default_Toggled;
    private boolean toggled;
    private int key;
    private String name;
    private HackCategory category;
    private boolean show;
    private ArrayList<Value> values;
    
    public Hack(final String name, final HackCategory category, final boolean Default) {
        this.values = new ArrayList<Value>();
        this.name = name;
        this.category = category;
        this.toggled = false;
        this.show = true;
        this.key = 0;
        this.Default = true;
        this.Default_Toggled = Default;
    }
    
    public Hack(final String name, final HackCategory category) {
        this.values = new ArrayList<Value>();
        this.name = name;
        this.category = category;
        this.toggled = false;
        this.show = true;
        this.key = 0;
        this.Default = false;
        this.Default_Toggled = false;
    }
    
    public boolean Default() {
        return this.Default;
    }
    
    public boolean Default_Toggled() {
        return this.Default_Toggled;
    }
    
    public HackCategory getCategory() {
        return this.category;
    }
    
    public void toggle() {
        this.toggled = !this.toggled;
        if (this.toggled) {
            this.onEnable();
        }
        else {
            this.onDisable();
        }
        FileManager.saveHacks(false);
        System.out.print("\n-------\nSpace:The configuration is saved\n-------\n");
        Disposal.Send0("Run " + this.getName() + ":" + this.isToggled());
    }
    
    public void addValue(final Value... values) {
        for (final Value value : values) {
            this.getValues().add(value);
        }
    }
    
    public void setModes(final String Name, final String mode) {
        if (!this.getValues().isEmpty()) {
            for (final Value value : this.values) {
                if (value.getName().equals(Name)) {
                    if (value instanceof BooleanValue) {
                        if (mode.equals("true")) {
                            value.setValue(true);
                        }
                        else {
                            value.setValue(false);
                        }
                        Disposal.Send30("Data-" + this.name + "." + value.getName() + "=" + value.getValue().toString());
                    }
                    if (value instanceof NumberValue) {
                        value.setValue(Double.valueOf(mode));
                        Disposal.Send30("Data-" + this.name + "." + value.getName() + "=" + value.getValue().toString());
                    }
                    if (!(value instanceof ModeValue)) {
                        continue;
                    }
                    final ModeValue modeValue = (ModeValue)value;
                    for (final Mode modeS : modeValue.getModes()) {
                        if (mode.equals(modeS.getName())) {
                            modeS.setToggled(true);
                        }
                        else {
                            modeS.setToggled(false);
                        }
                        Disposal.Send30(modeS.getName() + "." + modeS.isToggled());
                    }
                }
            }
        }
    }
    
    public ArrayList<Value> getValues() {
        return this.values;
    }
    
    public void setKey(final int key) {
        this.key = key;
    }
    
    public String getRenderName() {
        return this.name;
    }
    
    public boolean isShow() {
        return this.show;
    }
    
    public void setShow(final boolean show) {
        this.show = show;
    }
    
    public void setToggled100(final boolean toggled) {
        Disposal.Send100("Run " + this.name + ":" + toggled);
        this.toggled = toggled;
    }
    
    public void setToggled(final boolean toggled) {
        Disposal.Send0("Run " + this.name + ":" + toggled);
        this.toggled = toggled;
    }
    
    public void setToggledD(final boolean toggled) {
        this.toggled = toggled;
    }
    
    public boolean getToggled() {
        return this.toggled;
    }
    
    public int getKey() {
        if (this.key == -1) {
            return 0;
        }
        return this.key;
    }
    
    public boolean isToggledModeY(final String modeName) {
        for (final Value value : this.values) {
            if (value instanceof ModeValue) {
                final ModeValue modeValue = (ModeValue)value;
                for (final Mode mode : modeValue.getModes()) {
                    if (mode.getName().equalsIgnoreCase(modeName) && mode.isToggled()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean isToggledMode(final String Name, final String mode) {
        for (final Value value : this.values) {
            if (value.getName().equals(Name) && value instanceof ModeValue) {
                final ModeValue modeValue = (ModeValue)value;
                for (final Mode modeS : modeValue.getModes()) {
                    if (modeS.getName().equals(mode)) {
                        return modeS.isToggled();
                    }
                }
            }
        }
        return false;
    }
    
    public String onToggledMode(final String Name) {
        for (final Value value : this.values) {
            if (value.getName().equals(Name) && value instanceof ModeValue) {
                final ModeValue modeValue = (ModeValue)value;
                for (final Mode modeS : modeValue.getModes()) {
                    if (modeS.isToggled()) {
                        return modeS.getName();
                    }
                }
            }
        }
        return "";
    }
    
    public Double isNumberValue(final String NumberValue) {
        for (final Value value : this.values) {
            if (value.getName().equals(NumberValue) && value instanceof NumberValue) {
                final NumberValue numbervalue = (NumberValue)value;
                return numbervalue.getValue();
            }
        }
        return 0.0;
    }
    
    public boolean isBooleanValue(final String BooleanValue) {
        for (final Value value : this.values) {
            if (value.getName().equals(BooleanValue) && value instanceof BooleanValue) {
                final BooleanValue booleanValue = (BooleanValue)value;
                return booleanValue.getValue();
            }
        }
        return false;
    }
    
    public boolean isToggled() {
        return this.toggled;
    }
    
    public boolean isToggled2() {
        Disposal.Send100("Run " + this.name + ":" + this.toggled);
        return this.toggled;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void onEnable() {
    }
    
    public void onDisable() {
    }
    
    public boolean onPacket(final Object packet, final Connection.Side side) {
        return true;
    }
    
    public void onClientTick(final TickEvent.ClientTickEvent event) {
    }
    
    public void onLeftClickBlock(final PlayerInteractEvent event) {
    }
    
    public void onRightClickItem(final PlayerInteractEvent event) {
    }
    
    public void onAttackEntity(final AttackEntityEvent event) {
    }
    
    public void onPlayerMove(final LivingEvent.LivingUpdateEvent event) {
    }
    
    public void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
    }
    
    public void onCameraSetup(final EntityViewRenderEvent.CameraSetup event) {
    }
    
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
    }
    
    public void onMouse(final MouseEvent event) {
    }
    
    public void onInputUpdate(final TickEvent.PlayerTickEvent event) {
    }
    
    public boolean isToggledValue(final String valueName) {
        for (final Value value : this.values) {
            if (value instanceof BooleanValue) {
                final BooleanValue booleanValue = (BooleanValue)value;
                if (booleanValue.getName().equalsIgnoreCase(valueName) && booleanValue.getValue()) {
                    return true;
                }
                continue;
            }
        }
        return false;
    }
    
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
    }
    
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
    }
    
    public void onRender3D(final RenderBlockOverlayEvent event) {
    }
}
