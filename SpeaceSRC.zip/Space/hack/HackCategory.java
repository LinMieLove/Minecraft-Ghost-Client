package Space.hack;

public enum HackCategory
{
    Another, 
    Player, 
    Visual, 
    Combat, 
    Movement, 
    None;
}
