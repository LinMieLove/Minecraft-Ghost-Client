package Space.hack.hacks.Another;

import Space.hack.*;
import Space.value.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import Space.utils.*;

public class AntiBot extends Hack
{
    public AntiBot() {
        super("AntiBot", HackCategory.Another);
        final BooleanValue LivingTime = new BooleanValue("LivingTime", Boolean.valueOf(false));
        final NumberValue tick = new NumberValue("LivingTicks", 18.0, 0.1, 30.0);
        final BooleanValue ifInvisible = new BooleanValue("Invisible", Boolean.valueOf(false));
        final BooleanValue ifArmor = new BooleanValue("Armor", Boolean.valueOf(false));
        final BooleanValue ifInAir = new BooleanValue("InAir", Boolean.valueOf(false));
        final BooleanValue ifHealth = new BooleanValue("Health", Boolean.valueOf(false));
        final BooleanValue ifGround = new BooleanValue("OnGround", Boolean.valueOf(false));
        final BooleanValue ifEntityId = new BooleanValue("EntityId", Boolean.valueOf(false));
        final BooleanValue NameNPC = new BooleanValue("NameNPC", Boolean.valueOf(false));
        this.addValue(LivingTime, tick, ifInvisible, ifArmor, ifInAir, ifHealth, ifGround, ifEntityId, NameNPC);
    }
    
    public static boolean isBot(final EntityPlayer bot, final Hack hack) {
        if (hack.isBooleanValue("LivingTime")) {
            final double ticks = hack.isNumberValue("LivingTicks");
            if (ticks > 0.0 && bot.field_70173_aa < ticks) {
                return true;
            }
        }
        return (hack.isBooleanValue("InAir") && bot.func_82150_aj() && bot.field_70181_x == 0.0 && bot.field_70163_u > Wrapper.player().field_70163_u + 1.0 && BlockUtils.isBlockMaterial(new BlockPos((Entity)bot).func_177977_b(), Blocks.field_150350_a)) || (hack.isBooleanValue("OnGround") && bot.field_70181_x == 0.0 && !bot.field_70124_G && bot.field_70122_E && bot.field_70163_u % 1.0 != 0.0 && bot.field_70163_u % 0.5 != 0.0) || (hack.isBooleanValue("Health") && (bot.func_110143_aJ() <= 0.0f || bot.func_110143_aJ() > 20.0f)) || (hack.isBooleanValue("Invisible") && bot.func_82150_aj()) || (hack.isBooleanValue("EntityId") && bot.func_145782_y() >= 1000000000) || (hack.isBooleanValue("NameNPC") && bot.func_70005_c_().contains("[") && bot.func_70005_c_().contains("N") && bot.func_70005_c_().contains("P") && bot.func_70005_c_().contains("C") && bot.func_70005_c_().contains("]")) || (hack.isBooleanValue("Armor") && bot.field_71071_by.field_70460_b[0] == null && bot.field_71071_by.field_70460_b[1] == null && bot.field_71071_by.field_70460_b[2] == null && bot.field_71071_by.field_70460_b[3] == null);
    }
}
