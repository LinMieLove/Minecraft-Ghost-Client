package Space.hack.hacks.Another;

import Space.hack.*;
import Space.value.*;

public class Targets extends Hack
{
    public BooleanValue players;
    public BooleanValue mobs;
    public BooleanValue invisibles;
    public BooleanValue sleeping;
    
    public Targets() {
        super("Targets", HackCategory.Another, true);
        this.players = new BooleanValue("Players", Boolean.valueOf(true));
        this.mobs = new BooleanValue("Mobs", Boolean.valueOf(true));
        this.invisibles = new BooleanValue("Invisibles", Boolean.valueOf(false));
        this.sleeping = new BooleanValue("Sleeping", Boolean.valueOf(false));
        this.addValue(this.players, this.mobs, this.invisibles, this.sleeping);
    }
}
