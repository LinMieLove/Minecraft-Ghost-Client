package Space.hack.hacks.Another;

import Space.hack.*;
import Space.value.*;

public class Teams extends Hack
{
    public ModeValue mode;
    
    public Teams() {
        super("Teams", HackCategory.Another);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Base", false), new Mode("Armor", true), new Mode("Name", false) });
        this.addValue(this.mode);
    }
}
