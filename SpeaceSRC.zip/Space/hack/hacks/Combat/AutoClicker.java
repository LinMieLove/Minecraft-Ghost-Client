package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraft.entity.*;
import net.minecraft.client.settings.*;
import java.util.*;
import net.minecraft.entity.item.*;
import net.minecraftforge.client.event.*;
import Space.utils.*;

public class AutoClicker extends Hack
{
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public TimerUtils timer;
    public BooleanValue NoCapped;
    public ModeValue AutoAim;
    public ModeValue AutoAimpriority;
    public NumberValue AutoAimFOV;
    public NumberValue AutoAimrange;
    public BooleanValue NoAttack;
    public EntityLivingBase target;
    public ModeValue Circle;
    
    public AutoClicker() {
        super("AutoClicker", HackCategory.Combat);
        this.MaxCPS = new NumberValue("MaxCPS", 30.0, 1.0, 90.0);
        this.MinCPS = new NumberValue("MinCPS", 29.0, 1.0, 89.0);
        this.AutoAim = new ModeValue("AutoAim", new Mode[] { new Mode("Off", true), new Mode("Yaw", false), new Mode("Pitch", false), new Mode("Simple", false) });
        this.AutoAimpriority = new ModeValue("AimPriority", new Mode[] { new Mode("Closest", true), new Mode("Health", false), new Mode("Range", false) });
        this.AutoAimFOV = new NumberValue("AimFOV", 180.0, 1.0, 360.0);
        this.AutoAimrange = new NumberValue("AimRange", 5.6, 1.0, 10.0);
        this.Circle = new ModeValue("Circle", new Mode[] { new Mode("Normal", false), new Mode("Space", false), new Mode("None", true) });
        this.NoAttack = new BooleanValue("NoAttack", Boolean.valueOf(false));
        this.NoCapped = new BooleanValue("NoCapped", Boolean.valueOf(false));
        this.addValue(this.MaxCPS, this.MinCPS, this.AutoAim, this.AutoAimpriority, this.AutoAimFOV, this.AutoAimrange, this.Circle, this.NoAttack, this.NoCapped);
        this.timer = new TimerUtils();
    }
    
    @Override
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        if (this.target == null) {
            this.killAuraUpdate();
        }
        else if (!this.check(this.target)) {
            this.target = null;
            this.killAuraUpdate();
        }
        if (this.target == null) {
            return;
        }
        if (Wrapper.mc().field_71474_y.field_74312_F.func_151470_d()) {
            if (this.AutoAim.getMode("Simple").isToggled()) {
                Wrapper.player().field_70177_z = Utils.getYaw((Entity)this.target);
                Wrapper.player().field_70125_A = Utils.getPitch((Entity)this.target);
            }
            else if (this.AutoAim.getMode("Yaw").isToggled()) {
                Wrapper.player().field_70177_z = Utils.getYaw((Entity)this.target);
            }
            else if (this.AutoAim.getMode("Pitch").isToggled()) {
                Wrapper.player().field_70125_A = Utils.getPitch((Entity)this.target);
            }
            if (this.NoAttack.getValue()) {
                return;
            }
            if (this.AttacksProhibited(this.target)) {
                return;
            }
            if (!this.NoCapped.getValue()) {
                final int i = Utils.random((int)(Object)this.MinCPS.getValue(), (int)(Object)this.MaxCPS.getValue());
                final int j = Utils.random(1, 50);
                final int k = Utils.random(1, 60);
                final int l = Utils.random(1, 70);
                if (this.timer.isDelay((1000 + j - k + l) / i)) {
                    KeyBinding.func_74507_a(Wrapper.mc().field_71474_y.field_74312_F.func_151463_i());
                    this.timer.setLastMS();
                }
            }
            else {
                KeyBinding.func_74507_a(Wrapper.mc().field_71474_y.field_74312_F.func_151463_i());
            }
        }
        super.onRenderGameOverlay(event);
    }
    
    void killAuraUpdate() {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase) {
                final EntityLivingBase entitylivingbase = (EntityLivingBase)object;
                if (!this.isPriority(entitylivingbase) || !this.check(entitylivingbase)) {
                    continue;
                }
                this.target = entitylivingbase;
            }
        }
    }
    
    boolean isPriority(final EntityLivingBase entitylivingbase) {
        return (this.AutoAimpriority.getMode("Closest").isToggled() && ValidUtils.isClosest(entitylivingbase, this.target)) || (this.AutoAimpriority.getMode("Health").isToggled() && ValidUtils.isLowHealth(entitylivingbase, this.target)) || (this.AutoAimpriority.getMode("Range").isToggled() && ValidUtils.isRange(entitylivingbase, this.target));
    }
    
    public boolean check(final EntityLivingBase entitylivingbase) {
        return !(entitylivingbase instanceof EntityArmorStand) && !ValidUtils.isValidEntity(entitylivingbase) && ValidUtils.isNoScreen() && entitylivingbase != Wrapper.player() && !entitylivingbase.field_70128_L && entitylivingbase.field_70725_aQ <= 0 && !ValidUtils.isBot(entitylivingbase) && ValidUtils.isInvisible(entitylivingbase) && ValidUtils.isInAttackFOV(entitylivingbase, (int)(this.AutoAimFOV.getValue() / 2.0)) && this.isInAttackRange(entitylivingbase) && ValidUtils.isTeam(entitylivingbase) && Wrapper.player().func_70685_l((Entity)entitylivingbase);
    }
    
    boolean isInAttackRange(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= this.AutoAimrange.getValue();
    }
    
    boolean AttacksProhibited(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= 0.3;
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (this.target == null) {
            return;
        }
        if (!this.check(this.target)) {
            this.target = null;
            return;
        }
        if (this.Circle.getMode("None").isToggled()) {
            return;
        }
        if (this.Circle.getMode("Normal").isToggled()) {
            RenderUtils.CircleNormal(4.0);
        }
        else if (this.Circle.getMode("Space").isToggled()) {
            RenderUtils.CircleSpace(this.target);
        }
        super.onRenderWorldLast(event);
    }
}
