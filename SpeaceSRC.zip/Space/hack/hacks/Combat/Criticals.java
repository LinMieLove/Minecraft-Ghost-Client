package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.event.entity.player.*;
import Space.utils.*;

public class Criticals extends Hack
{
    public ModeValue mode;
    public NumberValue delay;
    public int ticks;
    
    public Criticals() {
        super("Criticals", HackCategory.Combat);
        this.ticks = 0;
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Visual", true), new Mode("Jump", false), new Mode("LowJump", false) });
        this.delay = new NumberValue("Delay", 3.0, 0.0, 20.0);
        this.addValue(this.mode, this.delay);
    }
    
    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        if (!Wrapper.player().field_70122_E || Wrapper.player().func_70617_f_() || Wrapper.player().func_70090_H() || Wrapper.player().func_180799_ab()) {
            return;
        }
        ++this.ticks;
        if (this.ticks >= this.delay.getValue()) {
            if (this.mode.getMode("Visual").isToggled()) {
                Wrapper.player().func_71009_b(event.target);
            }
            else if (this.mode.getMode("Jump").isToggled()) {
                Wrapper.player().field_70181_x = 0.42;
            }
            else if (this.mode.getMode("LowJump").isToggled()) {
                Wrapper.player().field_70181_x = 0.3425;
            }
            this.ticks = 0;
        }
    }
}
