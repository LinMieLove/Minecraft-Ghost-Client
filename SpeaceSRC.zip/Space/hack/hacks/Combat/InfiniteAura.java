package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.entity.player.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import Space.utils.*;
import net.minecraft.entity.item.*;

public class InfiniteAura extends Hack
{
    public ModeValue mode;
    public EntityLivingBase target;
    public ModeValue priority;
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public NumberValue FOV;
    public NumberValue range;
    public TimerUtils timer;
    public BooleanValue AutoAim;
    public BooleanValue walls;
    
    public InfiniteAura() {
        super("InfiniteAura", HackCategory.Combat, false);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Simple", true), new Mode("Packet", false), new Mode("Off", false) });
        this.priority = new ModeValue("Priority", new Mode[] { new Mode("Closest", true), new Mode("Health", false), new Mode("Range", false) });
        this.MaxCPS = new NumberValue("MaxCPS", 8.0, 1.0, 22.0);
        this.MinCPS = new NumberValue("MinCPS", 7.0, 1.0, 21.0);
        this.FOV = new NumberValue("FOV", 360.0, 1.0, 360.0);
        this.range = new NumberValue("Range", 100.0, 1.0, 100.0);
        this.AutoAim = new BooleanValue("AutoAim", Boolean.valueOf(false));
        this.walls = new BooleanValue("ThroughWalls", Boolean.valueOf(false));
        this.addValue(this.mode, this.priority, this.MaxCPS, this.MinCPS, this.FOV, this.range, this.AutoAim, this.walls);
        this.timer = new TimerUtils();
    }
    
    @Override
    public void onEnable() {
        this.timer = new TimerUtils();
        super.onEnable();
    }
    
    @Override
    public void onDisable() {
        this.target = null;
        super.onDisable();
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.target == null) {
            this.killAuraUpdate();
        }
        else if (!this.check(this.target)) {
            this.target = null;
            this.killAuraUpdate();
        }
        if (this.target == null) {
            return;
        }
        if (this.AutoAim.getValue()) {
            Wrapper.player().field_70177_z = Utils.getYaw((Entity)this.target);
        }
        final int i = Utils.random((int)(Object)this.MinCPS.getValue(), (int)(Object)this.MaxCPS.getValue());
        final int j = Utils.random(1, 50);
        final int k = Utils.random(1, 60);
        final int l = Utils.random(1, 70);
        if (this.timer.isDelay((1000 + j - k + l) / i)) {
            final double d0 = this.target.field_70165_t + 1.0 - 3.5 * Math.cos(Math.toRadians(Utils.getYaw((Entity)this.target) + 90.0f));
            final double d2 = this.target.field_70161_v + 1.0 - 3.5 * Math.sin(Math.toRadians(Utils.getYaw((Entity)this.target) + 90.0f));
            Wrapper.sendPacket((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(d0, this.target.field_70163_u + 1.0, d2, Utils.getYaw((Entity)this.target), Utils.getPitch((Entity)this.target), this.target.field_70122_E));
            if (this.mode.getMode("Simple").isToggled()) {
                Wrapper.mc().field_71442_b.func_78764_a((EntityPlayer)Wrapper.player(), (Entity)this.target);
            }
            if (this.mode.getMode("Packet").isToggled()) {
                Wrapper.sendPacket((Packet)new C02PacketUseEntity((Entity)this.target, C02PacketUseEntity.Action.ATTACK));
            }
            Wrapper.sendPacket((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.target.field_70165_t + 1.0, this.target.field_70163_u, this.target.field_70161_v + 1.0, this.target.field_70122_E));
            this.timer.setLastMS();
        }
        super.onClientTick(event);
    }
    
    void killAuraUpdate() {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase) {
                final EntityLivingBase entitylivingbase = (EntityLivingBase)object;
                if (!this.isPriority(entitylivingbase) || !this.check(entitylivingbase)) {
                    continue;
                }
                this.target = entitylivingbase;
            }
        }
    }
    
    boolean isPriority(final EntityLivingBase entitylivingbase) {
        return (this.priority.getMode("Closest").isToggled() && ValidUtils.isClosest(entitylivingbase, this.target)) || (this.priority.getMode("Health").isToggled() && ValidUtils.isLowHealth(entitylivingbase, this.target)) || (this.priority.getMode("Range").isToggled() && ValidUtils.isRange(entitylivingbase, this.target));
    }
    
    public boolean check(final EntityLivingBase entitylivingbase) {
        return !(entitylivingbase instanceof EntityArmorStand) && !ValidUtils.isValidEntity(entitylivingbase) && ValidUtils.isNoScreen() && entitylivingbase != Wrapper.player() && !entitylivingbase.field_70128_L && entitylivingbase.field_70725_aQ <= 0 && !ValidUtils.isBot(entitylivingbase) && ValidUtils.isInvisible(entitylivingbase) && ValidUtils.isInAttackFOV(entitylivingbase, (int)(this.FOV.getValue() / 2.0)) && this.isInAttackRange(entitylivingbase) && ValidUtils.isTeam(entitylivingbase) && Wrapper.player().func_70685_l((Entity)entitylivingbase);
    }
    
    boolean isInAttackRange(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= this.range.getValue();
    }
}
