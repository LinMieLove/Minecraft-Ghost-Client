package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.entity.item.*;
import net.minecraftforge.client.event.*;
import Space.utils.*;

public class KillAura extends Hack
{
    public static EntityLivingBase target;
    public ModeValue mode;
    public ModeValue priority;
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public NumberValue FOV;
    public TimerUtils timer;
    public NumberValue range;
    public ModeValue Circle;
    public NumberValue HurtTime;
    public NumberValue Delay;
    public BooleanValue Swing;
    public ModeValue Rotation;
    public BooleanValue AutoAttack;
    public int ticks;
    
    public KillAura() {
        super("KillAura", HackCategory.Combat, false);
        this.MaxCPS = new NumberValue("MaxCPS", 8.0, 1.0, 20.0);
        this.MinCPS = new NumberValue("MinCPS", 5.0, 1.0, 19.9);
        this.HurtTime = new NumberValue("HurtTime", 10.0, 0.0, 10.0);
        this.range = new NumberValue("Range", 4.4, 1.0, 8.0);
        this.Delay = new NumberValue("Delay", 0.0, 0.0, 3.0);
        this.Swing = new BooleanValue("Swing", Boolean.valueOf(false));
        this.AutoAttack = new BooleanValue("AutoAttack", Boolean.valueOf(false));
        this.priority = new ModeValue("Priority", new Mode[] { new Mode("Closest", true), new Mode("Health", false), new Mode("Range", false) });
        this.mode = new ModeValue("AttackMethod", new Mode[] { new Mode("AttackEntity", true), new Mode("Packet", false) });
        this.Rotation = new ModeValue("Rotation", new Mode[] { new Mode("Raven", true), new Mode("Galacticc", false), new Mode("Legit", false), new Mode("Not", false) });
        this.FOV = new NumberValue("FOV", 180.0, 1.0, 360.0);
        this.Circle = new ModeValue("Circle", new Mode[] { new Mode("Normal", true), new Mode("Space", false), new Mode("None", false) });
        this.addValue(this.MaxCPS, this.MinCPS, this.HurtTime, this.range, this.Delay, this.Swing, this.AutoAttack, this.priority, this.mode, this.Rotation, this.FOV, this.Circle);
        this.timer = new TimerUtils();
        this.ticks = 0;
    }
    
    @Override
    public void onEnable() {
        KillAura.target = null;
        super.onEnable();
    }
    
    @Override
    public void onDisable() {
        KillAura.target = null;
        super.onDisable();
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        this.killAuraUpdate();
        if (KillAura.target == null) {
            return;
        }
        if (this.AutoAttack.getValue()) {
            if (Wrapper.player().field_82175_bq && Wrapper.player().field_110158_av == 0) {
                this.processAttack();
                KillAura.target = null;
            }
        }
        else {
            final int i = Utils.random((int)(Object)this.MinCPS.getValue(), (int)(Object)this.MaxCPS.getValue());
            final int j = Utils.random(1, 50);
            final int k = Utils.random(1, 60);
            final int l = Utils.random(1, 70);
            if (this.timer.isDelay((1000 + j - k + l) / i)) {
                this.processAttack();
                this.timer.setLastMS();
                KillAura.target = null;
            }
        }
    }
    
    public void processAttack() {
        if (this.ticks >= this.Delay.getValue()) {
            if (this.Rotation.getMode("Raven").isToggled()) {
                Utils.aim((Entity)KillAura.target, 0.0f, true);
            }
            else if (this.Rotation.getMode("Legit").isToggled()) {
                Utils.aim((Entity)KillAura.target, 0.0f, false);
            }
            else if (this.Rotation.getMode("Galacticc").isToggled()) {
                Wrapper.player().field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Wrapper.player().field_70165_t, Wrapper.player().func_174813_aQ().field_72338_b, Wrapper.player().field_70161_v, Utils.getRotations((Entity)KillAura.target)[0], Utils.getRotations((Entity)KillAura.target)[1], Wrapper.player().field_70122_E));
            }
            if (this.Swing.getValue()) {
                Utils.swing();
            }
            if (this.mode.getMode("AttackEntity").isToggled()) {
                Utils.attack((Entity)KillAura.target);
            }
            else if (this.mode.getMode("Packet").isToggled()) {
                Wrapper.sendPacket((Packet)new C02PacketUseEntity((Entity)KillAura.target, C02PacketUseEntity.Action.ATTACK));
            }
            this.timer.setLastMS();
            this.ticks = 0;
        }
        ++this.ticks;
    }
    
    void killAuraUpdate() {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase) {
                final EntityLivingBase entitylivingbase = (EntityLivingBase)object;
                if (!this.isPriority(entitylivingbase) || entitylivingbase.field_70737_aN > this.HurtTime.getValue() || !this.check(entitylivingbase)) {
                    continue;
                }
                KillAura.target = entitylivingbase;
            }
        }
    }
    
    boolean isPriority(final EntityLivingBase entitylivingbase) {
        return (this.priority.getMode("Closest").isToggled() && ValidUtils.isClosest(entitylivingbase, KillAura.target)) || (this.priority.getMode("Health").isToggled() && ValidUtils.isLowHealth(entitylivingbase, KillAura.target)) || (this.priority.getMode("Range").isToggled() && ValidUtils.isRange(entitylivingbase, KillAura.target));
    }
    
    public boolean check(final EntityLivingBase entitylivingbase) {
        return !(entitylivingbase instanceof EntityArmorStand) && !ValidUtils.isValidEntity(entitylivingbase) && ValidUtils.isNoScreen() && entitylivingbase != Wrapper.player() && !entitylivingbase.field_70128_L && entitylivingbase.field_70725_aQ <= 0 && !ValidUtils.isBot(entitylivingbase) && ValidUtils.isInvisible(entitylivingbase) && ValidUtils.isInAttackFOV(entitylivingbase, (int)(this.FOV.getValue() / 2.0)) && this.isInAttackRange(entitylivingbase) && ValidUtils.isTeam(entitylivingbase) && Wrapper.player().func_70685_l((Entity)entitylivingbase);
    }
    
    boolean isInAttackRange(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= this.range.getValue();
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (KillAura.target == null) {
            return;
        }
        if (!this.check(KillAura.target)) {
            KillAura.target = null;
            return;
        }
        if (this.Circle.getMode("None").isToggled()) {
            return;
        }
        if (this.Circle.getMode("Normal").isToggled()) {
            RenderUtils.CircleNormal(4.0);
        }
        else if (this.Circle.getMode("Space").isToggled()) {
            RenderUtils.CircleSpace(KillAura.target);
        }
        super.onRenderWorldLast(event);
    }
    
    static {
        KillAura.target = null;
    }
}
