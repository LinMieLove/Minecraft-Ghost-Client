package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraft.entity.*;
import net.minecraft.client.settings.*;
import net.minecraftforge.client.event.*;
import java.util.*;
import Space.utils.*;
import net.minecraft.entity.item.*;

public class LeftAim extends Hack
{
    public EntityLivingBase target;
    public ModeValue mode;
    public ModeValue priority;
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public NumberValue FOV;
    public NumberValue range;
    public NumberValue CpsCappedRange;
    public TimerUtils timer;
    public BooleanValue CpsCapped;
    public BooleanValue NoAttack;
    public ModeValue Circle;
    
    public LeftAim() {
        super("LeftAim", HackCategory.Combat, false);
        this.target = null;
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Simple", true), new Mode("Yaw", false), new Mode("Pitch", false), new Mode("Off", false) });
        this.priority = new ModeValue("Priority", new Mode[] { new Mode("Closest", true), new Mode("Health", false), new Mode("Range", false) });
        this.MaxCPS = new NumberValue("MaxCPS", 30.0, 1.0, 90.0);
        this.MinCPS = new NumberValue("MinCPS", 29.0, 1.0, 89.0);
        this.FOV = new NumberValue("FOV", 360.0, 1.0, 360.0);
        this.range = new NumberValue("Range", 4.4, 1.0, 10.0);
        this.Circle = new ModeValue("Circle", new Mode[] { new Mode("Normal", true), new Mode("Space", false), new Mode("None", false) });
        this.NoAttack = new BooleanValue("NoAttack", Boolean.valueOf(false));
        this.CpsCapped = new BooleanValue("CpsCapped", Boolean.valueOf(false));
        this.CpsCappedRange = new NumberValue("CpsRange", 4.4, 1.0, 10.0);
        this.addValue(this.mode, this.priority, this.MaxCPS, this.MinCPS, this.FOV, this.range, this.Circle, this.NoAttack, this.CpsCapped, this.CpsCappedRange);
        this.timer = new TimerUtils();
    }
    
    @Override
    public void onEnable() {
        this.target = null;
        super.onEnable();
    }
    
    @Override
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        if (this.target == null) {
            this.killAuraUpdate();
        }
        else if (!this.check(this.target)) {
            this.target = null;
            this.killAuraUpdate();
        }
        if (this.target == null) {
            return;
        }
        if (!this.mode.getMode("Off").isToggled()) {
            if (this.mode.getMode("Simple").isToggled()) {
                Wrapper.player().field_70177_z = Utils.getYaw((Entity)this.target);
                Wrapper.player().field_70125_A = Utils.getPitch((Entity)this.target);
            }
            else if (this.mode.getMode("Yaw").isToggled()) {
                Wrapper.player().field_70177_z = Utils.getYaw((Entity)this.target);
            }
            else if (this.mode.getMode("Pitch").isToggled()) {
                Wrapper.player().field_70125_A = Utils.getPitch((Entity)this.target);
            }
        }
        if (this.NoAttack.getValue()) {
            return;
        }
        if (this.AttacksProhibited(this.target)) {
            return;
        }
        if (!this.CpsCapped.getValue()) {
            this.attack();
        }
        else if (this.isInAttackCpsCappedRange(this.target)) {
            KeyBinding.func_74507_a(Wrapper.mc().field_71474_y.field_74313_G.func_151463_i());
        }
        else {
            this.attack();
        }
        super.onRenderGameOverlay(event);
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (this.Circle.getMode("None").isToggled()) {
            return;
        }
        if (this.Circle.getMode("Normal").isToggled()) {
            RenderUtils.CircleNormal(this.range.getValue());
        }
        else if (this.Circle.getMode("Space").isToggled()) {
            RenderUtils.CircleSpace(this.target);
        }
        super.onRenderWorldLast(event);
    }
    
    public void attack() {
        final int i = Utils.random((int)(Object)this.MinCPS.getValue(), (int)(Object)this.MaxCPS.getValue());
        final int j = Utils.random(1, 50);
        final int k = Utils.random(1, 60);
        final int l = Utils.random(1, 70);
        if (this.timer.isDelay((1000 + j - k + l) / i)) {
            KeyBinding.func_74507_a(Wrapper.mc().field_71474_y.field_74313_G.func_151463_i());
            this.timer.setLastMS();
        }
    }
    
    void killAuraUpdate() {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase) {
                final EntityLivingBase entitylivingbase = (EntityLivingBase)object;
                if (!this.isPriority(entitylivingbase) || !this.check(entitylivingbase)) {
                    continue;
                }
                this.target = entitylivingbase;
            }
        }
    }
    
    boolean isPriority(final EntityLivingBase entitylivingbase) {
        return (this.priority.getMode("Closest").isToggled() && ValidUtils.isClosest(entitylivingbase, this.target)) || (this.priority.getMode("Health").isToggled() && ValidUtils.isLowHealth(entitylivingbase, this.target)) || (this.priority.getMode("Range").isToggled() && ValidUtils.isRange(entitylivingbase, this.target));
    }
    
    public boolean check(final EntityLivingBase entitylivingbase) {
        return !(entitylivingbase instanceof EntityArmorStand) && !ValidUtils.isValidEntity(entitylivingbase) && ValidUtils.isNoScreen() && entitylivingbase != Wrapper.player() && !entitylivingbase.field_70128_L && entitylivingbase.field_70725_aQ <= 0 && !ValidUtils.isBot(entitylivingbase) && ValidUtils.isInvisible(entitylivingbase) && ValidUtils.isInAttackFOV(entitylivingbase, (int)(this.FOV.getValue() / 2.0)) && this.isInAttackRange(entitylivingbase) && ValidUtils.isTeam(entitylivingbase) && Wrapper.player().func_70685_l((Entity)entitylivingbase);
    }
    
    boolean isInAttackRange(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= this.range.getValue();
    }
    
    boolean AttacksProhibited(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= 0.3;
    }
    
    boolean isInAttackCpsCappedRange(final EntityLivingBase entity) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= this.CpsCappedRange.getValue();
    }
}
