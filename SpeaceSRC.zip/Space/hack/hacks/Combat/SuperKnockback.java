package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.event.entity.player.*;
import Space.utils.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;

public class SuperKnockback extends Hack
{
    public ModeValue mode;
    public BooleanValue OnlyGround;
    public BooleanValue OnlyMove;
    public NumberValue HurtTime;
    
    public SuperKnockback() {
        super("SuperKnockback", HackCategory.Combat);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Sprint-Packet", true), new Mode("Sneak-Packet", false), new Mode("W-Tap", false) });
        this.HurtTime = new NumberValue("HurtTime", 10.0, 0.0, 10.0);
        this.OnlyGround = new BooleanValue("OnlyGround", Boolean.valueOf(false));
        this.OnlyMove = new BooleanValue("OnlyMove", Boolean.valueOf(false));
        this.addValue(this.mode, this.HurtTime, this.OnlyGround, this.OnlyMove);
    }
    
    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        if (event.target.field_70172_ad > this.HurtTime.getValue() || (this.OnlyGround.getValue() && !Wrapper.player().field_70122_E) || (this.OnlyMove.getValue() && !Utils.isMoving())) {
            return;
        }
        if (this.mode.getMode("Sprint-Packet").isToggled()) {
            if (Wrapper.player().func_70051_ag()) {
                Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.STOP_SPRINTING));
                Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.START_SPRINTING));
                Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.STOP_SPRINTING));
                Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.START_SPRINTING));
                Wrapper.player().func_70031_b(true);
            }
        }
        else if (this.mode.getMode("Sneak-Packet").isToggled()) {
            if (Wrapper.player().func_70051_ag()) {
                Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.STOP_SNEAKING));
            }
            Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.START_SNEAKING));
            Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.STOP_SNEAKING));
        }
        else if (this.mode.getMode("W-Tap").isToggled()) {
            if (Wrapper.player().func_70051_ag()) {
                Wrapper.player().func_70031_b(false);
            }
            Wrapper.player().func_70031_b(true);
            Wrapper.player().func_70031_b(false);
            Wrapper.player().func_70031_b(true);
        }
    }
}
