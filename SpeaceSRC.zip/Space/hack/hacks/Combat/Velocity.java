package Space.hack.hacks.Combat;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.client.entity.*;
import Space.utils.*;
import net.minecraft.network.play.server.*;

public class Velocity extends Hack
{
    public ModeValue mode;
    public static Boolean velocityInput;
    public BooleanValue OnlyGround;
    
    public Velocity() {
        super("Velocity", HackCategory.Combat);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Simple", true), new Mode("Jump", false), new Mode("Hypixel", false) });
        this.OnlyGround = new BooleanValue("OnlyGround", Boolean.valueOf(false));
        this.addValue(this.mode, this.OnlyGround);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.inStrafe()) {
            return;
        }
        if (this.mode.getMode("Jump").isToggled()) {
            final EntityPlayerSP player = Wrapper.player();
            if (player.field_70737_aN > 0 && player.field_70122_E) {
                player.field_70181_x = 0.42;
                final float yaw = player.field_70177_z * 0.017453292f;
                final EntityPlayerSP entityPlayerSP = player;
                entityPlayerSP.field_70159_w -= MathUtils.sin(yaw) * 0.2;
                final EntityPlayerSP entityPlayerSP2 = player;
                entityPlayerSP2.field_70179_y += MathUtils.cos(yaw) * 0.2;
            }
        }
        super.onClientTick(event);
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        if (!this.mode.getMode("Simple").isToggled() && !this.mode.getMode("Hypixel").isToggled()) {
            return true;
        }
        if (this.inStrafe()) {
            return true;
        }
        if (packet instanceof S12PacketEntityVelocity && this.mode.getMode("Simple").isToggled() && Wrapper.player().field_70737_aN >= 0) {
            final S12PacketEntityVelocity p = (S12PacketEntityVelocity)packet;
            if (p.func_149412_c() == Wrapper.player().func_145782_y()) {
                return false;
            }
        }
        else if (packet instanceof S12PacketEntityVelocity && this.mode.getMode("Hypixel").isToggled() && Wrapper.player().field_70737_aN >= 0) {
            final S12PacketEntityVelocity p = (S12PacketEntityVelocity)packet;
            if (p.func_149412_c() == Wrapper.player().func_145782_y()) {
                Wrapper.player().field_70181_x = p.func_149410_e() / 8000.0;
            }
        }
        return true;
    }
    
    public boolean inStrafe() {
        return this.OnlyGround.getValue() && !Wrapper.player().field_70122_E;
    }
    
    static {
        Velocity.velocityInput = false;
    }
}
