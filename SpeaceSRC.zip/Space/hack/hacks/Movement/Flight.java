package Space.hack.hacks.Movement;

import net.minecraft.network.play.client.*;
import Space.hack.*;
import java.util.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.client.entity.*;
import Space.utils.*;

public class Flight extends Hack
{
    Queue<C03PacketPlayer> packets;
    List<C03PacketPlayer> p;
    private NumberValue flytimer;
    private BooleanValue XYZ;
    boolean send;
    public ModeValue mode;
    int ticks;
    
    public Flight() {
        super("Flight", HackCategory.Movement, false);
        this.packets = new LinkedList<C03PacketPlayer>();
        this.p = new ArrayList<C03PacketPlayer>();
        this.send = false;
        this.ticks = 0;
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Simple", true), new Mode("Dynamic", false), new Mode("Hypixel", false) });
        this.flytimer = new NumberValue("Timer", 1.0, 0.1, 1.2);
        this.XYZ = new BooleanValue("AntiKick", Boolean.valueOf(true));
        this.addValue(this.mode, this.flytimer, this.XYZ);
    }
    
    @Override
    public void onEnable() {
        this.ticks = 0;
        super.onEnable();
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        final EntityPlayerSP player = Wrapper.player();
        if (this.mode.getMode("Hypixel").isToggled()) {
            player.field_70181_x = 0.0;
            player.func_70031_b(true);
            player.field_70122_E = true;
            ++this.ticks;
            if (this.ticks == 2 || this.ticks == 4 || this.ticks == 6 || this.ticks == 8 || this.ticks == 10 || this.ticks == 12 || this.ticks == 14 || this.ticks == 16 || this.ticks == 18 || this.ticks == 20) {
                player.func_70107_b(player.field_70165_t + this.flytimer.getValue(), player.field_70163_u + 1.28E-9, player.field_70161_v + this.flytimer.getValue());
            }
            if (this.ticks == 20) {
                this.ticks = 0;
            }
        }
        else if (this.mode.getMode("Simple").isToggled()) {
            player.field_71075_bZ.field_75100_b = true;
            if (Wrapper.mc().field_71474_y.field_74351_w.func_151470_d()) {
                player.field_70159_w *= this.flytimer.getValue();
                player.field_70179_y *= this.flytimer.getValue();
            }
        }
        else if (this.mode.getMode("Dynamic").isToggled()) {
            if (this.XYZ.getValue() && Wrapper.player().field_70173_aa % 4 == 0) {
                Wrapper.player().field_70181_x = -0.03999999910593033;
            }
            final Double flyspeed = this.flytimer.getValue();
            player.field_70747_aH = 0.4f;
            player.field_70159_w = 0.0;
            player.field_70181_x = 0.0;
            player.field_70179_y = 0.0;
            final EntityPlayerSP entityPlayerSP3;
            final EntityPlayerSP entityPlayerSP = entityPlayerSP3 = player;
            entityPlayerSP3.field_70747_aH *= (float)(flyspeed * 3.0);
            if (Wrapper.mc().field_71474_y.field_74314_A.func_151470_d()) {
                if (this.XYZ.getValue()) {
                    Wrapper.player().field_70181_x = ((Wrapper.player().field_70173_aa % 20 == 0) ? -0.03999999910593033 : flyspeed);
                }
                else {
                    final EntityPlayerSP entityPlayerSP4;
                    final EntityPlayerSP entityPlayerSP2 = entityPlayerSP4 = player;
                    entityPlayerSP4.field_70181_x += flyspeed;
                }
            }
        }
        super.onClientTick(event);
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        return true;
    }
    
    @Override
    public void onDisable() {
        if (this.mode.getMode("Simple").isToggled()) {
            Wrapper.player().field_71075_bZ.field_75100_b = false;
        }
        this.packets.clear();
        super.onDisable();
    }
}
