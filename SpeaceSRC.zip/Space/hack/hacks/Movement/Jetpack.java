package Space.hack.hacks.Movement;

import Space.hack.*;
import net.minecraftforge.fml.common.gameevent.*;
import Space.utils.*;

public class Jetpack extends Hack
{
    public Jetpack() {
        super("Jetpack", HackCategory.Movement, false);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Wrapper.mc().field_71474_y.field_74314_A.func_151470_d()) {
            Wrapper.player().func_70664_aZ();
        }
        super.onClientTick(event);
    }
}
