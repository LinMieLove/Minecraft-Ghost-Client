package Space.hack.hacks.Movement;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import Space.utils.*;

public class LongJump extends Hack
{
    public ModeValue mode;
    int jumptick;
    boolean Ground;
    private BooleanValue AutoExit;
    
    public LongJump() {
        super("LongJump", HackCategory.Movement, false);
        this.jumptick = 0;
        this.Ground = false;
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("9JUMP", true), new Mode("12JUMP", false), new Mode("15JUMP", false), new Mode("17JUMP", false), new Mode("25JUMP", false) });
        this.AutoExit = new BooleanValue("AutoExit", Boolean.valueOf(false));
        this.addValue(this.mode, this.AutoExit);
    }
    
    @Override
    public void onEnable() {
        this.jumptick = 0;
        this.Ground = false;
        super.onEnable();
    }
    
    public int JUMP() {
        if (this.mode.getMode("9JUMP").isToggled()) {
            return 9;
        }
        if (this.mode.getMode("12JUMP").isToggled()) {
            return 12;
        }
        if (this.mode.getMode("15JUMP").isToggled()) {
            return 15;
        }
        if (this.mode.getMode("17JUMP").isToggled()) {
            return 17;
        }
        if (this.mode.getMode("25JUMP").isToggled()) {
            return 25;
        }
        return 0;
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (!this.AutoExit.getValue() && this.Ground && this.jumptick > this.JUMP()) {
            this.jumptick = 0;
            this.Ground = false;
        }
        if (!this.Ground && Wrapper.player().field_70122_E) {
            this.Ground = true;
        }
        if (this.Ground && this.jumptick < this.JUMP() + 1) {
            Wrapper.player().func_70664_aZ();
            ++this.jumptick;
        }
        else if (this.AutoExit.getValue()) {
            this.setToggled(false);
        }
        super.onClientTick(event);
    }
}
