package Space.hack.hacks.Movement;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import Space.utils.*;
import net.minecraft.client.entity.*;

public class Speed extends Hack
{
    public ModeValue mode;
    int LBasicTick;
    
    public Speed() {
        super("Speed", HackCategory.Movement, false);
        this.LBasicTick = 0;
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("HYT", true), new Mode("4JUMP", false), new Mode("5JUMP", false), new Mode("HYTS", false), new Mode("Basic", false), new Mode("LBasic", false) });
        this.addValue(this.mode);
    }
    
    @Override
    public void onEnable() {
        this.LBasicTick = 0;
        super.onEnable();
    }
    
    @Override
    public void onInputUpdate(final TickEvent.PlayerTickEvent event) {
        if ((this.mode.getMode("HYT").isToggled() || this.mode.getMode("HYTS").isToggled() || this.mode.getMode("5JUMP").isToggled() || this.mode.getMode("4JUMP").isToggled()) && (Wrapper.player().field_71158_b.field_78900_b > 0.0f || Wrapper.player().field_71158_b.field_78902_a > 0.0f) && Wrapper.player().field_70122_E) {
            Wrapper.player().func_70664_aZ();
            if (this.mode.getMode("HYTS").isToggled() || this.mode.getMode("5JUMP").isToggled() || this.mode.getMode("4JUMP").isToggled()) {
                Wrapper.player().func_70664_aZ();
                if (this.mode.getMode("5JUMP").isToggled() || this.mode.getMode("4JUMP").isToggled()) {
                    Wrapper.player().func_70664_aZ();
                    Wrapper.player().func_70664_aZ();
                    if (this.mode.getMode("5JUMP").isToggled()) {
                        Wrapper.player().func_70664_aZ();
                    }
                }
            }
        }
        super.onInputUpdate(event);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("Basic").isToggled() || this.mode.getMode("LBasic").isToggled()) {
            final boolean boost = Math.abs(Wrapper.player().field_70759_as - Wrapper.player().field_70177_z) < 90.0f;
            if (Wrapper.player().field_70701_bs > 0.0f && Wrapper.player().field_70737_aN < 5) {
                if (Wrapper.player().field_70122_E) {
                    Wrapper.player().field_70181_x = 0.405;
                    final float f = Utils.getDirection();
                    final EntityPlayerSP player3;
                    final EntityPlayerSP player = player3 = Wrapper.player();
                    player3.field_70159_w -= Math.sin(f) * 0.20000000298023224;
                    final EntityPlayerSP player4;
                    final EntityPlayerSP player2 = player4 = Wrapper.player();
                    player4.field_70179_y += Math.cos(f) * 0.20000000298023224;
                }
                else {
                    final double currentSpeed = Math.sqrt(Wrapper.player().field_70159_w * Wrapper.player().field_70159_w + Wrapper.player().field_70179_y * Wrapper.player().field_70179_y);
                    final double speed = boost ? 1.0064 : 1.001;
                    final double direction = Utils.getDirection();
                    Wrapper.player().field_70159_w = -Math.sin(direction) * speed * currentSpeed;
                    Wrapper.player().field_70179_y = Math.cos(direction) * speed * currentSpeed;
                }
                ++this.LBasicTick;
                if (this.mode.getMode("LBasic").isToggled() && this.LBasicTick > 40) {
                    this.setToggled(false);
                }
            }
        }
        super.onClientTick(event);
    }
}
