package Space.hack.hacks.Movement;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import Space.utils.*;

public class Sprint extends Hack
{
    public ModeValue Mode;
    
    public Sprint() {
        super("Sprint", HackCategory.Movement);
        this.Mode = new ModeValue("Priority", new Mode[] { new Mode("Strict", false), new Mode("KeepSprint", true) });
        this.addValue(this.Mode);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (!Wrapper.player().func_70051_ag()) {
            if (this.Mode.getMode("Strict").isToggled() && !Wrapper.player().field_70122_E) {
                return;
            }
            Wrapper.player().func_70031_b(true);
        }
        super.onClientTick(event);
    }
}
