package Space.hack.hacks.Movement;

import Space.hack.*;
import net.minecraftforge.fml.common.gameevent.*;
import Space.utils.*;

public class TnTFly extends Hack
{
    public TnTFly() {
        super("TnTFly", HackCategory.Movement, false);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Wrapper.mc().field_71474_y.field_74314_A.func_151470_d()) {
            Wrapper.player().func_70080_a(Wrapper.player().field_70165_t + 1000.0, Wrapper.player().field_70163_u, Wrapper.player().field_70161_v, Wrapper.player().field_70177_z, Wrapper.player().field_70125_A);
        }
        else {
            Wrapper.player().func_70080_a(Wrapper.player().field_70165_t - 1000.0, Wrapper.player().field_70163_u, Wrapper.player().field_70161_v, Wrapper.player().field_70177_z, Wrapper.player().field_70125_A);
        }
        super.onClientTick(event);
    }
}
