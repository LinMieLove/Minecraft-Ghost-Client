package Space.hack.hacks.Player;

import Space.hack.*;
import Space.value.*;
import Space.utils.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraft.block.state.*;
import net.minecraft.enchantment.*;
import net.minecraft.item.*;

public class AutoTool extends Hack
{
    public ModeValue priority;
    
    public AutoTool() {
        super("AutoTool", HackCategory.Player);
        this.priority = new ModeValue("Priority", new Mode[] { new Mode("Weapon", false), new Mode("Tool", false), new Mode("All", true) });
        this.addValue(this.priority);
    }
    
    @Override
    public void onLeftClickBlock(final PlayerInteractEvent event) {
        if (this.priority.getMode("Weapon").isToggled()) {
            return;
        }
        Utils.nullCheck();
        this.equipBestTool(Wrapper.world().func_180495_p(event.pos));
    }
    
    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        if (this.priority.getMode("Tool").isToggled()) {
            return;
        }
        Utils.nullCheck();
        equipBestWeapon();
    }
    
    private void equipBestTool(final IBlockState blockState) {
        int bestSlot = -1;
        double max = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = Wrapper.player().field_71071_by.func_70301_a(i);
            if (stack != null) {
                float speed = stack.func_77973_b().getDigSpeed(stack, blockState);
                if (speed > 1.0f) {
                    final float eff = EnchantmentHelper.func_77506_a(Enchantment.field_77349_p.field_77352_x, stack);
                    if (eff > 0.0f) {
                        speed += (float)(Math.pow(eff, 2.0) + 1.0);
                    }
                    else {
                        speed += (float)0.0;
                    }
                    if (speed > max) {
                        max = speed;
                        bestSlot = i;
                    }
                }
            }
        }
        if (bestSlot != -1) {
            equip(bestSlot);
        }
    }
    
    public static void equipBestWeapon() {
        int bestSlot = -1;
        double maxDamage = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = Wrapper.player().field_71071_by.func_70301_a(i);
            if (stack != null && stack.func_77973_b() instanceof ItemSword) {
                final double baseDamage = ((ItemSword)stack.func_77973_b()).func_150931_i();
                final double enchantmentBonus = EnchantmentHelper.func_77506_a(Enchantment.field_180314_l.field_77352_x, stack) * 0.6000000238418579;
                final double damage = baseDamage + enchantmentBonus + 1.0;
                if (damage > maxDamage) {
                    maxDamage = damage;
                    bestSlot = i;
                }
            }
        }
        if (bestSlot != -1) {
            equip(bestSlot);
        }
    }
    
    private static void equip(final int slot) {
        Wrapper.player().field_71071_by.field_70461_c = slot;
    }
}
