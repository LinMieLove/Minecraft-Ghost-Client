package Space.hack.hacks.Player;

import Space.hack.*;
import Space.value.*;
import Space.utils.*;
import net.minecraft.network.play.server.*;
import Space.*;

public class ChatTranslator extends Hack
{
    public ModeValue mode;
    
    public ChatTranslator() {
        super("ChatTranslator", HackCategory.Player);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Strict", true), new Mode("Insist", false) });
        this.addValue(this.mode);
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        if (packet instanceof S02PacketChat) {
            final String msg = ((S02PacketChat)packet).func_148915_c().func_150254_d();
            if (!msg.contains("<") && !msg.contains(">") && !msg.contains(":") && !msg.contains("\u951f\u65a4\u62f7") && !msg.contains("\u951f\u65a4\u62f7")) {
                return true;
            }
            if (msg.equals(" ") || msg.equals("0") || msg.equals("\n") || msg.equals("/") || msg.contains("gg") || msg.contains("GG") || msg.contains("----") || msg.contains("====") || msg.contains("????") || msg.contains("+") || msg.contains("    ") || msg.contains("(!)") || msg.contains("joined the ") || msg.contains("lobby") || msg.contains("hub") || msg.contains("\u951f\u65a4\u62f7\u951f\u65a4\u62f7") || msg.contains("\u951f\u65a4\u62f7\u951f\u65a4\u62f7\u951f\u65a4\u62f7") || msg.contains("\u951f\u63ed\u7889\u62f7\u951f\u65a4\u62f7") || msg.contains("\u524d\u951f\u65a4\u62f7") || msg.contains("\u951f\u65a4\u62f7\u951f\u65a4\u62f7") || msg.contains(" found ") || msg.contains("????") || msg.contains("The game starts") || msg.contains("????") || msg.equals("`") || msg.equals("~") || msg.equals("\u951f\u65a4\u62f7") || msg.equals("\u951f\u65a4\u62f7") || msg.equals("!") || msg.equals("\u951f\u65a4\u62f7") || msg.equals(".") || msg.equals(",") || msg.equals("\u951f\u65a4\u62f7") || msg.equals("*") || msg.equals("?")) {
                return true;
            }
            if (this.mode.getMode("Strict").isToggled()) {
                Disposal.Send60("ChatTranslator:[" + msg + "]-Strict");
            }
            else if (this.mode.getMode("Insist").isToggled()) {
                Disposal.Send60("ChatTranslator:[" + msg + "]-Insist");
            }
        }
        return true;
    }
}
