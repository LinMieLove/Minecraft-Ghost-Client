package Space.hack.hacks.Player;

import net.minecraft.util.*;
import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.entity.*;
import net.minecraftforge.client.event.*;
import Space.utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.settings.*;
import net.minecraft.client.entity.*;
import net.minecraft.block.*;

public class Eagle extends Hack
{
    BooleanValue OnGround;
    BooleanValue Mark;
    BlockPos blockDown;
    public NumberValue edgeSpeed;
    
    public Eagle() {
        super("Eagle", HackCategory.Player, false);
        this.OnGround = new BooleanValue("OnGround", Boolean.valueOf(false));
        this.Mark = new BooleanValue("Mark", Boolean.valueOf(true));
        this.edgeSpeed = new NumberValue("Speed", 0.0, 0.0, 20.0);
        this.addValue(this.OnGround, this.Mark, this.edgeSpeed);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (!this.Mark.getValue()) {
            return;
        }
        this.blockDown = new BlockPos((Entity)Wrapper.player()).func_177977_b();
        super.onClientTick(event);
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (!this.Mark.getValue()) {
            return;
        }
        if (this.blockDown != null) {
            RenderUtils.drawBlockESP(this.blockDown, 1.0f, 1.0f, 1.0f);
        }
        super.onRenderWorldLast(event);
    }
    
    @Override
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        final EntityPlayerSP player = Wrapper.player();
        if (this.OnGround.getValue() && !player.field_70122_E) {
            this.setToggled(false);
        }
        if (getBlockUnderPlayer((EntityPlayer)player) instanceof BlockAir && player.field_70122_E && player.func_70040_Z().field_72448_b < -0.6660000085830688) {
            KeyBinding.func_74510_a(Wrapper.mc().field_71474_y.field_74311_E.func_151463_i(), true);
        }
        else {
            KeyBinding.func_74510_a(Wrapper.mc().field_71474_y.field_74311_E.func_151463_i(), false);
        }
        super.onPlayerTick(event);
    }
    
    public static Block getBlock(final BlockPos pos) {
        return Wrapper.world().func_180495_p(pos).func_177230_c();
    }
    
    public static Block getBlockUnderPlayer(final EntityPlayer player) {
        return getBlock(new BlockPos(player.field_70165_t, player.field_70163_u - 1.0, player.field_70161_v));
    }
}
