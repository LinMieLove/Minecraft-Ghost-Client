package Space.hack.hacks.Player;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.client.*;
import Space.utils.*;
import java.lang.reflect.*;

public class FastPlace extends Hack
{
    private NumberValue delaySlider;
    public BooleanValue OnlyWool;
    public BooleanValue OnlyGlass;
    Boolean Only;
    
    public FastPlace() {
        super("FastPlace", HackCategory.Player);
        this.Only = false;
        this.delaySlider = new NumberValue("delaySlider", 0.0, 0.0, 2.0);
        this.OnlyWool = new BooleanValue("OnlyWool", Boolean.valueOf(false));
        this.OnlyGlass = new BooleanValue("OnlyGlass", Boolean.valueOf(false));
        this.addValue(this.delaySlider, this.OnlyWool, this.OnlyGlass);
    }
    
    @Override
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (this.OnlyWool.getValue() && this.OnlyGlass.getValue()) {
            this.Only = ((this.OnlyWool.getValue() && Wrapper.player().func_70694_bm().func_82833_r().contains("Wool")) || Wrapper.player().func_70694_bm().func_82833_r().contains("\u7f07\u5a43\u763a") || Wrapper.player().func_70694_bm().func_82833_r().contains("Glass") || Wrapper.player().func_70694_bm().func_82833_r().contains("\u941c\u8364\u62d1"));
        }
        else {
            if (this.OnlyWool.getValue()) {
                this.Only = (Wrapper.player().func_70694_bm().func_82833_r().contains("Wool") || Wrapper.player().func_70694_bm().func_82833_r().contains("\u7f07\u5a43\u763a"));
            }
            if (this.OnlyGlass.getValue()) {
                this.Only = (Wrapper.player().func_70694_bm().func_82833_r().contains("Glass") || Wrapper.player().func_70694_bm().func_82833_r().contains("\u941c\u8364\u62d1"));
            }
        }
        final Field field = ReflectionHelper.findField(Minecraft.class, "field_71467_ac", "rightClickDelayTimer");
        if (this.Only) {
            try {
                field.setInt(Wrapper.mc(), (int)(this.delaySlider.getValue() + 0.0));
            }
            catch (Exception ex) {}
        }
        else if (!this.OnlyWool.getValue() && !this.OnlyGlass.getValue()) {
            try {
                field.setInt(Wrapper.mc(), (int)(this.delaySlider.getValue() + 0.0));
            }
            catch (Exception ex2) {}
        }
    }
}
