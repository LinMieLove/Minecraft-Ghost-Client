package Space.hack.hacks.Player;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import Space.utils.*;
import net.minecraftforge.fml.relauncher.*;
import java.lang.reflect.*;

public class NoFall extends Hack
{
    public ModeValue mode;
    
    public NoFall() {
        super("NoFall", HackCategory.Player);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("AAC", false), new Mode("Simple", true) });
        this.addValue(this.mode);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("Simple").isToggled() && Wrapper.player().field_70143_R > 2.0f) {
            Wrapper.sendPacket((Packet)new C03PacketPlayer(true));
        }
        super.onClientTick(event);
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        if (side == Connection.Side.OUT && packet instanceof C03PacketPlayer) {
            final C03PacketPlayer p = (C03PacketPlayer)packet;
            if (this.mode.getMode("AAC").isToggled()) {
                final Field field = ReflectionHelper.findField((Class)C03PacketPlayer.class, new String[] { "onGround", "onGround" });
                try {
                    if (!field.isAccessible()) {
                        field.setAccessible(true);
                    }
                    field.setBoolean(p, true);
                }
                catch (Exception ex) {}
            }
        }
        return true;
    }
}
