package Space.hack.hacks.Visual;

import Space.hack.*;
import net.minecraftforge.client.event.*;
import Space.utils.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.item.*;

public class ArmorHUD extends Hack
{
    public ArmorHUD() {
        super("ArmorHUD", HackCategory.Visual);
    }
    
    @Override
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        final ScaledResolution resolution = new ScaledResolution(Wrapper.mc());
        final RenderItem itemRender = Wrapper.mc().func_175599_af();
        GlStateManager.func_179098_w();
        final int i = resolution.func_78326_a() / 2;
        int iteration = 0;
        final int y = resolution.func_78328_b() - 55 - (Wrapper.player().func_70090_H() ? 10 : 0);
        for (final ItemStack is : Wrapper.player().field_71071_by.field_70460_b) {
            ++iteration;
            if (is != null) {
                final int x = i - 90 + (9 - iteration) * 20 + 2;
                GlStateManager.func_179094_E();
                GlStateManager.func_179121_F();
                GlStateManager.func_179126_j();
                itemRender.field_77023_b = 200.0f;
                itemRender.func_180450_b(is, x, y);
                itemRender.func_180453_a(Wrapper.fontRenderer(), is, x, y, "");
                itemRender.field_77023_b = 0.0f;
                GlStateManager.func_179098_w();
                GlStateManager.func_179140_f();
                GlStateManager.func_179097_i();
                String s;
                if (is.field_77994_a > 1) {
                    s = Integer.toString(is.field_77994_a);
                }
                else {
                    s = "";
                }
                Wrapper.fontRenderer().func_175063_a(s, (float)(x + 19 - 2 - Wrapper.fontRenderer().func_78256_a(s)), (float)(y + 9), 16777215);
                GlStateManager.func_179126_j();
                GlStateManager.func_179140_f();
            }
        }
    }
}
