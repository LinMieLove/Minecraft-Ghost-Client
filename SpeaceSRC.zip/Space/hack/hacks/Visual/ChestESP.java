package Space.hack.hacks.Visual;

import java.util.*;
import Space.hack.*;
import net.minecraftforge.client.event.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import Space.utils.*;

public class ChestESP extends Hack
{
    private int maxChests;
    public boolean shouldInform;
    private ArrayDeque<TileEntityChest> emptyChests;
    private ArrayDeque<TileEntityChest> nonEmptyChests;
    private String[] chestClasses;
    
    public ChestESP() {
        super("ChestESP", HackCategory.Visual);
        this.maxChests = 1000;
        this.shouldInform = true;
        this.emptyChests = new ArrayDeque<TileEntityChest>();
        this.nonEmptyChests = new ArrayDeque<TileEntityChest>();
        this.chestClasses = new String[] { "TileEntityIronChest", "TileEntityGoldChest", "TileEntityDiamondChest", "TileEntityCopperChest", "TileEntitySilverChest", "TileEntityCrystalChest", "TileEntityObsidianChest", "TileEntityDirtChest" };
    }
    
    @Override
    public void onEnable() {
        this.shouldInform = true;
        this.emptyChests.clear();
        this.nonEmptyChests.clear();
        super.onEnable();
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        int chests = 0;
        for (int i = 0; i < Wrapper.world().field_147482_g.size(); ++i) {
            final TileEntity tileEntity = Wrapper.world().field_147482_g.get(i);
            if (chests >= this.maxChests) {
                break;
            }
            if (tileEntity instanceof TileEntityChest) {
                ++chests;
                final TileEntityChest chest = (TileEntityChest)tileEntity;
                final boolean trapped = chest.func_145832_p() == 1;
                if (this.emptyChests.contains(tileEntity)) {
                    RenderUtils.drawBlockESP(chest.func_174877_v(), 0.25f, 0.25f, 0.25f);
                }
                else if (this.nonEmptyChests.contains(tileEntity)) {
                    if (trapped) {
                        RenderUtils.drawBlockESP(chest.func_174877_v(), 0.0f, 1.0f, 0.0f);
                    }
                    else {
                        RenderUtils.drawBlockESP(chest.func_174877_v(), 1.0f, 0.0f, 0.0f);
                    }
                }
                else if (trapped) {
                    RenderUtils.drawBlockESP(chest.func_174877_v(), 0.0f, 1.0f, 0.0f);
                }
                else {
                    RenderUtils.drawBlockESP(chest.func_174877_v(), 1.0f, 0.0f, 0.0f);
                }
                if (trapped) {
                    RenderUtils.drawBlockESP(chest.func_174877_v(), 0.0f, 1.0f, 0.0f);
                }
                else {
                    RenderUtils.drawBlockESP(chest.func_174877_v(), 1.0f, 0.0f, 0.0f);
                }
            }
            else if (tileEntity instanceof TileEntityEnderChest) {
                ++chests;
                RenderUtils.drawBlockESP(((TileEntityEnderChest)tileEntity).func_174877_v(), 1.0f, 0.0f, 1.0f);
            }
            else {
                try {
                    for (final String chestClass : this.chestClasses) {
                        final Class clazz = Class.forName("cpw.mods.ironchest.common.tileentity.chest." + chestClass);
                        if (clazz != null && clazz.isInstance(tileEntity)) {
                            RenderUtils.drawBlockESP(tileEntity.func_174877_v(), 0.7f, 0.7f, 0.7f);
                        }
                    }
                }
                catch (ClassNotFoundException ex) {}
            }
        }
        for (int i = 0; i < Utils.getEntityList().size(); ++i) {
            final Entity entity = Utils.getEntityList().get(i);
            if (chests >= this.maxChests) {
                break;
            }
            if (entity instanceof EntityMinecartChest) {
                ++chests;
                RenderUtils.drawBlockESP(((EntityMinecartChest)entity).func_180425_c(), 1.0f, 1.0f, 1.0f);
            }
        }
        if (chests >= this.maxChests && this.shouldInform) {
            ChatUtils.warning("To prevent lag, it will only show the first " + this.maxChests + " chests.");
            this.shouldInform = false;
        }
        else if (chests < this.maxChests) {
            this.shouldInform = true;
        }
        super.onRenderWorldLast(event);
    }
}
