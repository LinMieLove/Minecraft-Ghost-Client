package Space.hack.hacks.Visual;

import net.minecraft.entity.player.*;
import Space.hack.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.entity.*;
import net.minecraftforge.client.event.*;
import java.text.*;
import java.awt.*;
import net.minecraft.client.entity.*;
import Space.utils.*;
import net.minecraft.util.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.gui.*;

public class EnemyInfo extends Hack
{
    private boolean show;
    private double enemyDistance;
    private EntityPlayer entityPlayer;
    
    public EnemyInfo() {
        super("EnemyInfo", HackCategory.Visual);
    }
    
    @Override
    public void onPlayerTick(final TickEvent.PlayerTickEvent e) {
        final MovingObjectPosition objectMouseOver = Wrapper.mc().field_71476_x;
        if (objectMouseOver != null) {
            if (objectMouseOver.field_72313_a == MovingObjectPosition.MovingObjectType.ENTITY) {
                final Entity entity = objectMouseOver.field_72308_g;
                if (entity instanceof EntityPlayer) {
                    this.entityPlayer = (EntityPlayer)entity;
                    this.enemyDistance = this.entityPlayer.func_70032_d((Entity)Wrapper.player());
                    this.show = true;
                }
            }
            else {
                this.show = false;
            }
        }
        else {
            this.show = false;
        }
    }
    
    @Override
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        if (this.entityPlayer == null) {
            return;
        }
        final RenderGameOverlayEvent.ElementType type = event.type;
        if (!type.equals((Object)RenderGameOverlayEvent.ElementType.TEXT)) {
            return;
        }
        final float Health = (this.entityPlayer.func_110143_aJ() < 0.0f) ? 0.0f : this.entityPlayer.func_110143_aJ();
        if (this.entityPlayer.func_110143_aJ() == 0.0f || !this.show || Wrapper.world() == null || Wrapper.player() == null) {
            return;
        }
        final DecimalFormat decimalFormat = new DecimalFormat("###.#");
        final FontRenderer fr = Wrapper.mc().field_71466_p;
        fr.func_78276_b(this.entityPlayer.func_70005_c_(), 335, 246, new Color(255, 255, 255).getRGB());
        fr.func_78276_b("Distanse: " + decimalFormat.format(this.enemyDistance), 336, 256, new Color(255, 255, 255).getRGB());
        fr.func_78276_b("HP: " + Math.round(Health), 336, 265, new Color(255, 255, 255).getRGB());
        final AbstractClientPlayer abstractPlayer = (AbstractClientPlayer)this.entityPlayer;
        final ResourceLocation skinLocation = abstractPlayer.func_110306_p();
        this.drawHead(skinLocation, 304, 247, 28, 28, 1.0f);
        RenderUtils.drawBorderedRect(290.0f + ((((Health > 20.0f) ? 20.0f : Health) < 4.0f) ? 15.0f : (((Health > 20.0f) ? 20.0f : Health) * 6.0f)), 277.0, 304.0, 275.98, new Color(255, 88, 41).getRGB());
    }
    
    void drawHead(final ResourceLocation skin, final int x, final int y, final int width, final int height, final float alpha) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, alpha);
        Wrapper.mc().func_110434_K().func_110577_a(skin);
        Gui.func_152125_a(x, y, 8.0f, 8.0f, 8, 8, width, height, 64.0f, 64.0f);
    }
}
