package Space.hack.hacks.Visual;

import Space.hack.*;
import Space.value.*;
import Space.utils.*;
import net.minecraft.client.settings.*;

public class Fov extends Hack
{
    public NumberValue FOV;
    private float oldFov;
    
    public Fov() {
        super("Fov", HackCategory.Visual);
        this.oldFov = 0.0f;
        this.FOV = new NumberValue("FOV", 140.0, 0.0, 500.0);
        this.addValue(this.FOV);
    }
    
    @Override
    public void onEnable() {
        if (!Utils.isPlayerInGame()) {
            return;
        }
        this.oldFov = Wrapper.mc().field_71474_y.func_74296_a(GameSettings.Options.FOV);
        Wrapper.mc().field_71474_y.field_74334_X = (float)(Object)this.FOV.getValue();
        super.onEnable();
    }
    
    @Override
    public void onDisable() {
        if (!Utils.isPlayerInGame()) {
            return;
        }
        Wrapper.mc().field_71474_y.field_74334_X = this.oldFov;
        super.onDisable();
    }
}
