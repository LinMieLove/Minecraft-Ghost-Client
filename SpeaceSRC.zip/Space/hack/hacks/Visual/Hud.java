package Space.hack.hacks.Visual;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.client.event.*;
import Space.managers.*;
import Space.utils.*;
import java.awt.*;
import java.util.*;
import java.util.regex.*;

public class Hud extends Hack
{
    public ModeValue mode;
    public BooleanValue ArrayList;
    public BooleanValue Keystrokes;
    public static int SameColor;
    public static ArrayList<String> modexy;
    
    public Hud() {
        super("Hud", HackCategory.Visual);
        this.mode = new ModeValue("Settings", new Mode[] { new Mode("Double-click", true) });
        this.ArrayList = new BooleanValue("ArrayList", Boolean.valueOf(true));
        this.Keystrokes = new BooleanValue("Keystrokes", Boolean.valueOf(false));
        this.addValue(this.mode, this.ArrayList, this.Keystrokes);
    }
    
    @Override
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        int rainbowTickc = 0;
        final ArrayList<Hack> hacks = new ArrayList<Hack>();
        hacks.addAll(HackManager.hacks);
        for (final Hack h : HackManager.getSortedHacks()) {
            if (!h.isToggled()) {
                continue;
            }
            if (++rainbowTickc > 100) {
                rainbowTickc = 0;
            }
            for (final Value value : h.getValues()) {
                if (value instanceof ModeValue) {
                    final ModeValue modeValue = (ModeValue)value;
                    if (!modeValue.getModeName().equals("Mode")) {
                        continue;
                    }
                    for (final Mode mode : modeValue.getModes()) {
                        if (mode.isToggled()) {}
                    }
                }
            }
            final Color rainbow = new Color(Color.HSBtoRGB((float)(Wrapper.player().field_70173_aa / 50.0 - Math.sin(rainbowTickc / 40.0 * 1.4)) % 1.0f, 1.0f, 1.0f));
            Hud.SameColor = rainbow.getRGB();
        }
        if (this.ArrayList.getValue()) {
            HArrayList2();
        }
        if (this.Keystrokes.getValue()) {
            HKeystrokes2();
        }
        super.onRenderGameOverlay(event);
    }
    
    public static void HArrayList2() {
        final String Name = "ArrayList";
        for (final String line : Hud.modexy) {
            if (line.contains("[Name:\"" + Name + "\"")) {
                final Pattern pattern = Pattern.compile("X:\"(-?\\d+(?:\\.\\d+)?)\" Y:\"(-?\\d+(?:\\.\\d+)?)\"");
                final Matcher matcher = pattern.matcher(line);
                if (!matcher.find()) {
                    continue;
                }
                final double x = Double.parseDouble(matcher.group(1));
                final double y = Double.parseDouble(matcher.group(2));
                HudNSDArrayList.HArrayList(x, y);
            }
        }
    }
    
    public static void HKeystrokes2() {
        final String Name = "Keystrokes";
        for (final String line : Hud.modexy) {
            if (line.contains("[Name:\"" + Name + "\"")) {
                final Pattern pattern = Pattern.compile("X:\"(-?\\d+(?:\\.\\d+)?)\" Y:\"(-?\\d+(?:\\.\\d+)?)\"");
                final Matcher matcher = pattern.matcher(line);
                if (!matcher.find()) {
                    continue;
                }
                final double x = Double.parseDouble(matcher.group(1));
                final double y = Double.parseDouble(matcher.group(2));
                HudNSDKeystrokes.getRenderer().renderKeystrokes((int)x, (int)y);
            }
        }
    }
    
    static {
        Hud.modexy = new ArrayList<String>();
    }
}
