package Space.hack.hacks.Visual;

import Space.hack.*;
import Space.value.*;
import Space.managers.*;
import Space.utils.font.*;
import java.awt.*;
import Space.utils.*;
import java.util.*;

public class HudNSDArrayList extends Hack
{
    public NumberValue TitleRed;
    public BooleanValue ListRainbow;
    public BooleanValue TitleRainbow;
    public NumberValue TagsColor;
    public NumberValue ListRed;
    public NumberValue ListGreen;
    public NumberValue ListBlue;
    public ModeValue TitleName;
    public ModeValue TagsStyle;
    public NumberValue TitleGreen;
    public NumberValue TitleBlue;
    
    public HudNSDArrayList() {
        super("HudNSDArrayList", HackCategory.None, true);
        this.TitleName = new ModeValue("TitleName", new Mode[] { new Mode("Space", true), new Mode("Nirvana", false), new Mode("Zelix", false), new Mode("Leave", false), new Mode("VapeV4", false), new Mode("VapeLite", false), new Mode("LiquidBounce", false), new Mode("None", false) });
        this.TagsStyle = new ModeValue("TagsStyle", new Mode[] { new Mode("Default", true), new Mode("One", false), new Mode("Two", false), new Mode("Three", false), new Mode("Four", false), new Mode("Five", false) });
        this.TitleRainbow = new BooleanValue("TitleRainbow", Boolean.valueOf(true));
        this.TitleRed = new NumberValue("TitleRed", 0.0, 0.0, 255.0);
        this.TitleGreen = new NumberValue("TitleGreen", 111.0, 0.0, 255.0);
        this.TitleBlue = new NumberValue("TitleBlue", 255.0, 0.0, 255.0);
        this.ListRainbow = new BooleanValue("ListRainbow", Boolean.valueOf(true));
        this.ListRed = new NumberValue("ListRed", 0.0, 0.0, 255.0);
        this.ListGreen = new NumberValue("ListGreen", 111.0, 0.0, 255.0);
        this.ListBlue = new NumberValue("ListBlue", 255.0, 0.0, 255.0);
        this.TagsColor = new NumberValue("TagsColor", 7.0, 0.0, 10.0);
        this.addValue(this.TitleName, this.TagsStyle, this.TitleRainbow, this.TitleRed, this.TitleGreen, this.TitleBlue, this.ListRainbow, this.ListRed, this.ListGreen, this.ListBlue, this.TagsColor);
    }
    
    public static String GetTagsStyle(final String Nn1, final String Nn2) {
        if ((int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("TagsColor") == 10) {
            return GetTags(Nn1 + Nn2, "");
        }
        return GetTags(Nn1 + "\u6402" + (int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("TagsColor"), Nn2);
    }
    
    public static String GetTags(final String front, final String behind) {
        final String hack = HackManager.getHack("HudNSDArrayList").onToggledMode("TagsStyle");
        if (hack.equals("Default")) {
            return front + " " + behind;
        }
        if (hack.equals("One")) {
            return front + " - " + behind;
        }
        if (hack.equals("Two")) {
            return front + " | " + behind;
        }
        if (hack.equals("Three")) {
            return front + " (" + behind + ")";
        }
        if (hack.equals("Four")) {
            return front + " [" + behind + "]";
        }
        if (hack.equals("Five")) {
            return front + " <" + behind + ">";
        }
        return "";
    }
    
    public static String GetName() {
        return HackManager.getHack("HudNSDArrayList").onToggledMode("TitleName");
    }
    
    public static void HArrayList(final double X, final double Y) {
        if (HackManager.getHack("HudNSDArrayList").isBooleanValue("TitleRainbow")) {
            FontLoaders.default29.drawString(GetName(), X, Y, Hud.SameColor, false);
        }
        else {
            FontLoaders.default29.drawString(GetName(), X, Y, new Color((int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("TitleRed"), (int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("TitleGreen"), (int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("TitleBlue")).getRGB(), false);
        }
        Double index = Y + 16.0;
        int DrawColor = -1;
        final ArrayList<Hack> hacks = new ArrayList<Hack>();
        hacks.addAll(HackManager.hacks);
        for (final Hack h : HackManager.getSortedHacks()) {
            String modeName = "";
            if (!h.isToggled()) {
                continue;
            }
            for (final Value value : h.getValues()) {
                if (value instanceof ModeValue) {
                    final ModeValue modeValue = (ModeValue)value;
                    if (!modeValue.getModeName().equals("Mode")) {
                        continue;
                    }
                    for (final Mode mode : modeValue.getModes()) {
                        if (mode.isToggled()) {
                            modeName = GetTagsStyle(modeName, mode.getName());
                        }
                    }
                }
            }
            if (HackManager.getHack("HudNSDArrayList").isBooleanValue("ListRainbow")) {
                DrawColor = Hud.SameColor;
            }
            else {
                DrawColor = new Color((int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("ListRed"), (int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("ListGreen"), (int)(Object)HackManager.getHack("HudNSDArrayList").isNumberValue("ListBlue")).getRGB();
            }
            if (h.getRenderName().equals("Hud") || h.getRenderName().equals("NightVision") || h.getRenderName().equals("PacketChat") || h.getRenderName().contains("NSD")) {
                continue;
            }
            FontLoaders.SFB17.drawString(h.getRenderName() + modeName, (float)X + 2.0f, (int)(index + 3.0), DrawColor);
            index += (Double)Wrapper.fontRenderer().field_78288_b;
        }
    }
}
