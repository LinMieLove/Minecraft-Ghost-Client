package Space.hack.hacks.Visual;

import Space.hack.hacks.Visual.UI.keystrokesmod.*;
import Space.hack.*;
import Space.value.*;

public class HudNSDKeystrokes extends Hack
{
    public BooleanValue Mouse;
    public BooleanValue TitleRainbow;
    public NumberValue TitleRed;
    public NumberValue TitleGreen;
    public NumberValue TitleBlue;
    private static KeystrokesRenderer renderer;
    
    public HudNSDKeystrokes() {
        super("HudNSDKeystrokes", HackCategory.None, true);
        this.Mouse = new BooleanValue("Mouse", Boolean.valueOf(true));
        this.TitleRainbow = new BooleanValue("TitleRainbow", Boolean.valueOf(true));
        this.TitleRed = new NumberValue("TitleRed", 255.0, 0.0, 255.0);
        this.TitleGreen = new NumberValue("TitleGreen", 255.0, 0.0, 255.0);
        this.TitleBlue = new NumberValue("TitleBlue", 255.0, 0.0, 255.0);
        this.addValue(this.Mouse, this.TitleRainbow, this.TitleRed, this.TitleGreen, this.TitleBlue);
        HudNSDKeystrokes.renderer = new KeystrokesRenderer();
    }
    
    public static KeystrokesRenderer getRenderer() {
        return HudNSDKeystrokes.renderer;
    }
}
