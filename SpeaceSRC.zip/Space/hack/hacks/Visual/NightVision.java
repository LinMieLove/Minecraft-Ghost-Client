package Space.hack.hacks.Visual;

import Space.hack.*;
import Space.value.*;
import Space.utils.*;
import net.minecraftforge.fml.common.gameevent.*;

public class NightVision extends Hack
{
    public ModeValue mode;
    
    public NightVision() {
        super("NightVision", HackCategory.Visual);
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Brightness", true), new Mode("Effect", false) });
        this.addValue(this.mode);
    }
    
    @Override
    public void onDisable() {
        if (this.mode.getMode("Brightness").isToggled()) {
            Wrapper.mc().field_71474_y.field_74333_Y = 1.0f;
        }
        else {
            Utils.removeEffect(16);
        }
        super.onDisable();
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("Brightness").isToggled()) {
            Wrapper.mc().field_71474_y.field_74333_Y = 10.0f;
        }
        else {
            Utils.addEffect(16, 1000, 3);
        }
        super.onClientTick(event);
    }
}
