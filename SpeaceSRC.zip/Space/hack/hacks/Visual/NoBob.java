package Space.hack.hacks.Visual;

import Space.hack.*;
import net.minecraftforge.fml.common.gameevent.*;
import Space.utils.*;

public class NoBob extends Hack
{
    public NoBob() {
        super("NoBob", HackCategory.Visual);
    }
    
    @Override
    public void onInputUpdate(final TickEvent.PlayerTickEvent event) {
        Wrapper.player().field_70140_Q = 0.0f;
    }
}
