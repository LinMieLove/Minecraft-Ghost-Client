package Space.hack.hacks.Visual;

import Space.hack.*;
import Space.value.*;
import net.minecraftforge.client.event.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import org.lwjgl.opengl.*;
import Space.utils.*;
import java.awt.*;
import net.minecraft.client.entity.*;
import net.minecraft.client.gui.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.enchantment.*;
import net.minecraft.client.renderer.entity.*;

public class Profiler extends Hack
{
    public BooleanValue armor;
    public BooleanValue NoRed;
    public BooleanValue BotDisplayed;
    
    public Profiler() {
        super("Profiler", HackCategory.Visual);
        this.armor = new BooleanValue("Armor", Boolean.valueOf(true));
        this.NoRed = new BooleanValue("NoRed", Boolean.valueOf(true));
        this.BotDisplayed = new BooleanValue("BotDisplayed", Boolean.valueOf(true));
        this.addValue(this.armor, this.NoRed, this.BotDisplayed);
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase) {
                final EntityLivingBase entity = (EntityLivingBase)object;
                final RenderManager renderManager = Wrapper.mc().func_175598_ae();
                final double renderPosX = renderManager.field_78730_l;
                final double renderPosY = renderManager.field_78731_m;
                final double renderPosZ = renderManager.field_78728_n;
                final double xPos = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * event.partialTicks - renderPosX;
                final double yPos = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * event.partialTicks - renderPosY;
                final double zPos = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * event.partialTicks - renderPosZ;
                this.renderNameTag(entity, entity.func_70005_c_(), xPos, yPos, zPos);
            }
        }
        super.onRenderWorldLast(event);
    }
    
    void renderNameTag(final EntityLivingBase entity, String tag, final double x, double y, final double z) {
        if (entity instanceof EntityArmorStand || ValidUtils.isValidEntity(entity) || entity == Wrapper.player()) {
            return;
        }
        if (this.NoRed.getValue() && (entity.func_70005_c_().contains(" 4 ") || entity.func_70005_c_().contains(" c "))) {
            return;
        }
        int color = ColorUtils.color(200, 200, 200, 160);
        final EntityPlayerSP player = Wrapper.player();
        final FontRenderer fontRenderer = Wrapper.fontRenderer();
        y += (entity.func_70093_af() ? 0.5 : 0.7);
        float distance = player.func_70032_d((Entity)entity) / 4.0f;
        if (distance < 1.6f) {
            distance = 1.6f;
        }
        if (entity instanceof EntityPlayer) {
            final EntityPlayer entityPlayer = (EntityPlayer)entity;
            final String ID = Utils.getPlayerName(entityPlayer);
            if (ValidUtils.isBot((EntityLivingBase)entityPlayer)) {
                if (this.BotDisplayed.getValue()) {
                    return;
                }
                tag = " e " + ID;
                color = ColorUtils.color(200, 200, 0, 160);
            }
        }
        final int health = (int)entity.func_110143_aJ();
        if (health <= entity.func_110138_aP() * 0.25) {
            tag += " 4 ";
        }
        else if (health <= entity.func_110138_aP() * 0.5) {
            tag += " 6 ";
        }
        else if (health <= entity.func_110138_aP() * 0.75) {
            tag += " e ";
        }
        else if (health <= entity.func_110138_aP()) {
            tag += " 2 ";
        }
        tag = String.valueOf(tag) + " " + Math.round(health);
        final RenderManager renderManager = Wrapper.mc().func_175598_ae();
        float scale = distance;
        scale /= 30.0f;
        scale *= 0.3;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y + 1.4f, (float)z);
        GL11.glRotatef(-renderManager.field_78735_i, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(renderManager.field_78732_j, 1.0f, 0.0f, 0.0f);
        GL11.glScalef(-scale, -scale, scale);
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        final Tessellator var14 = Tessellator.func_178181_a();
        final WorldRenderer var15 = var14.func_178180_c();
        final int width = fontRenderer.func_78256_a(tag) / 2;
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        RenderUtils.drawRect(-width - 2, -(fontRenderer.field_78288_b + 1), width + 2, 2.0f, color);
        fontRenderer.func_175065_a(tag, (float)(MathUtils.getMiddle(-width - 2, width + 2) - width), (float)(-(fontRenderer.field_78288_b - 1)), Color.WHITE.getRGB(), true);
        if (entity instanceof EntityPlayer && this.armor.getValue()) {
            final EntityPlayer entityPlayer2 = (EntityPlayer)entity;
            GlStateManager.func_179109_b(0.0f, 1.0f, 0.0f);
            this.renderArmor(entityPlayer2, 0, -(fontRenderer.field_78288_b + 1) - 20);
            GlStateManager.func_179109_b(0.0f, -1.0f, 0.0f);
        }
        GL11.glPopMatrix();
    }
    
    public void renderArmor(final EntityPlayer player, int x, final int y) {
        final InventoryPlayer items = player.field_71071_by;
        final ItemStack inHand = player.field_71071_by.func_70448_g();
        final ItemStack boots = items.func_70440_f(0);
        final ItemStack leggings = items.func_70440_f(1);
        final ItemStack body = items.func_70440_f(2);
        final ItemStack helm = items.func_70440_f(3);
        ItemStack[] stuff = null;
        if (inHand != null) {
            stuff = new ItemStack[] { inHand, helm, body, leggings, boots };
        }
        else {
            stuff = new ItemStack[] { helm, body, leggings, boots };
        }
        final List<ItemStack> stacks = new ArrayList<ItemStack>();
        ItemStack[] array;
        for (int length = (array = stuff).length, j = 0; j < length; ++j) {
            final ItemStack i = array[j];
            if (i != null && i.func_77973_b() != null) {
                stacks.add(i);
            }
        }
        final int width = 16 * stacks.size() / 2;
        x -= width;
        GlStateManager.func_179097_i();
        for (final ItemStack stack : stacks) {
            this.renderItem(stack, x, y);
            x += 16;
        }
        GlStateManager.func_179126_j();
    }
    
    public void renderItem(final ItemStack stack, final int x, int y) {
        final FontRenderer fontRenderer = Wrapper.fontRenderer();
        final RenderItem renderItem = Wrapper.mc().func_175599_af();
        final EnchantEntry[] enchants = { new EnchantEntry(Enchantment.field_180310_c, "Pro"), new EnchantEntry(Enchantment.field_92091_k, "Th"), new EnchantEntry(Enchantment.field_180314_l, "Shar"), new EnchantEntry(Enchantment.field_77334_n, "Fire"), new EnchantEntry(Enchantment.field_180313_o, "Kb"), new EnchantEntry(Enchantment.field_77347_r, "Unb"), new EnchantEntry(Enchantment.field_77345_t, "Pow"), new EnchantEntry(Enchantment.field_77342_w, "Inf"), new EnchantEntry(Enchantment.field_77344_u, "Punch") };
        GlStateManager.func_179094_E();
        GlStateManager.func_179094_E();
        final float scale1 = 0.3f;
        GlStateManager.func_179109_b((float)(x - 3), (float)(y + 10), 0.0f);
        GlStateManager.func_179152_a(0.3f, 0.3f, 0.3f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74520_c();
        renderItem.field_77023_b = -100.0f;
        GlStateManager.func_179097_i();
        renderItem.func_175042_a(stack, x, y);
        renderItem.func_180453_a(fontRenderer, stack, x, y, (String)null);
        GlStateManager.func_179126_j();
        EnchantEntry[] array;
        for (int length = (array = enchants).length, i = 0; i < length; ++i) {
            final EnchantEntry enchant = array[i];
            final int level = EnchantmentHelper.func_77506_a(enchant.getEnchant().field_77352_x, stack);
            String levelDisplay = "" + level;
            if (level > 10) {
                levelDisplay = "10+";
            }
            if (level > 0) {
                final float scale2 = 0.32f;
                GlStateManager.func_179109_b((float)(x - 2), (float)(y + 1), 0.0f);
                GlStateManager.func_179152_a(0.42f, 0.42f, 0.42f);
                GlStateManager.func_179097_i();
                GlStateManager.func_179140_f();
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                fontRenderer.func_175065_a(" F " + enchant.getName() + " " + levelDisplay, (float)(20 - fontRenderer.func_78256_a(" F " + enchant.getName() + " " + levelDisplay) / 2), 0.0f, Color.WHITE.getRGB(), true);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.func_179145_e();
                GlStateManager.func_179126_j();
                GlStateManager.func_179152_a(2.42f, 2.42f, 2.42f);
                GlStateManager.func_179109_b((float)(-x), (float)(-y), 0.0f);
                y += (int)((fontRenderer.field_78288_b + 3) * 0.28f);
            }
        }
        renderItem.field_77023_b = 0.0f;
        RenderHelper.func_74518_a();
        GlStateManager.func_179141_d();
        GlStateManager.func_179084_k();
        GlStateManager.func_179140_f();
        GlStateManager.func_179121_F();
    }
    
    public static class EnchantEntry
    {
        private Enchantment enchant;
        private String name;
        
        public EnchantEntry(final Enchantment enchant, final String name) {
            this.enchant = enchant;
            this.name = name;
        }
        
        public Enchantment getEnchant() {
            return this.enchant;
        }
        
        public String getName() {
            return this.name;
        }
    }
}
