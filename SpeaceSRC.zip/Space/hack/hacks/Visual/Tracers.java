package Space.hack.hacks.Visual;

import Space.hack.*;
import net.minecraftforge.client.event.*;
import net.minecraft.entity.item.*;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import Space.utils.*;

public class Tracers extends Hack
{
    public Tracers() {
        super("Tracers", HackCategory.Visual);
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase && !(object instanceof EntityArmorStand)) {
                final EntityLivingBase entity = (EntityLivingBase)object;
                this.render(entity, event.partialTicks);
            }
        }
        super.onRenderWorldLast(event);
    }
    
    void render(final EntityLivingBase entity, final float ticks) {
        if (ValidUtils.isValidEntity(entity) || entity == Wrapper.player()) {
            return;
        }
        if (entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)entity;
            Utils.getPlayerName(player);
        }
        if (entity.func_82150_aj()) {
            RenderUtils.drawTracer((Entity)entity, 0.0f, 0.0f, 0.0f, 0.5f, ticks);
            return;
        }
        if (entity.field_70737_aN > 0) {
            RenderUtils.drawTracer((Entity)entity, 1.0f, 0.0f, 0.0f, 1.0f, ticks);
            return;
        }
        RenderUtils.drawTracer((Entity)entity, 1.0f, 1.0f, 1.0f, 0.5f, ticks);
    }
}
