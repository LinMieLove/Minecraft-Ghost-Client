package Space.hack.hacks.Visual.UI;

import Space.managers.*;
import Space.value.*;
import net.minecraft.client.gui.*;
import Space.hack.*;
import java.util.*;
import Space.utils.*;

public class GuiCustomScreen extends GuiScreen
{
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    public int Create;
    
    public GuiCustomScreen() {
        this.Create = 0;
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        this.field_146292_n.clear();
        final int centerX = this.field_146294_l / 2;
        final int centerY = this.field_146295_m / 2;
        this.Create = 0;
        final Hack hack = HackManager.getHack("Hud");
        for (final Value value : hack.getValues()) {
            if (value instanceof BooleanValue) {
                ++this.Create;
                final GuiButton button = new GuiButton(this.Create, centerX - 100, centerY - 10 - 20 + 20 * this.Create, 200, 20, value.getName());
                this.field_146292_n.add(button);
            }
        }
    }
    
    protected void func_146284_a(final GuiButton button) {
        HackManager.getHack("Hud").setToggledD(false);
        Wrapper.mc().func_147108_a((GuiScreen)new GuiDraggableMenu(button.field_146126_j));
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        this.func_146276_q_();
        final int centerX = this.field_146294_l / 2;
        final int centerY = this.field_146295_m / 2;
        final String title = "Settings";
        this.func_73732_a(this.field_146289_q, title, centerX, centerY - 30, 16777215);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
    
    public boolean func_73868_f() {
        return false;
    }
}
