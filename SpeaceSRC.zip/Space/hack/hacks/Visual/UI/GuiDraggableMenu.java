package Space.hack.hacks.Visual.UI;

import Space.managers.*;
import Space.hack.hacks.Visual.*;
import java.io.*;
import net.minecraft.client.gui.*;

public class GuiDraggableMenu extends GuiScreen
{
    private int posX;
    private int posY;
    private int lastMouseX;
    private int lastMouseY;
    private String Name;
    
    public GuiDraggableMenu(final String name) {
        FileManager.loadHud(name);
        this.Name = name;
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
    }
    
    public void func_146281_b() {
        HackManager.getHack("Hud").setToggledD(true);
        FileManager.saveHud();
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        super.func_73863_a(mouseX, mouseY, partialTicks);
        if (this.Name.contains("ArrayList")) {
            Hud.HArrayList2();
        }
        else if (this.Name.contains("Keystrokes")) {
            Hud.HKeystrokes2();
        }
    }
    
    protected void func_73864_a(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        if (mouseX >= this.posX && mouseY >= this.posY && mouseX < this.posX + 100 && mouseY < this.posY + 20) {
            this.lastMouseX = mouseX;
            this.lastMouseY = mouseY;
        }
    }
    
    protected void func_146273_a(final int mouseX, final int mouseY, final int clickedMouseButton, final long timeSinceLastClick) {
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
        this.posX += mouseX - this.lastMouseX;
        this.posY += mouseY - this.lastMouseY;
        this.lastMouseX = mouseX;
        this.lastMouseY = mouseY;
        FileManager.SetHud(this.Name, String.valueOf(this.posX), String.valueOf(this.posY));
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_146284_a(final GuiButton button) throws IOException {
        super.func_146284_a(button);
    }
}
