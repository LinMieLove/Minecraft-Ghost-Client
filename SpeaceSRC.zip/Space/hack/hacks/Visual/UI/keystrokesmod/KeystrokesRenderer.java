package Space.hack.hacks.Visual.UI.keystrokesmod;

import Space.utils.*;
import Space.hack.hacks.Visual.*;
import java.awt.*;
import net.minecraft.client.gui.*;
import Space.managers.*;

public class KeystrokesRenderer
{
    private static final int[] COLORS;
    private final Key[] movementKeys;
    private final MouseButton[] mouseButtons;
    
    public KeystrokesRenderer() {
        this.movementKeys = new Key[4];
        this.mouseButtons = new MouseButton[2];
        this.movementKeys[0] = new Key(Wrapper.mc().field_71474_y.field_74351_w, 26, 2);
        this.movementKeys[1] = new Key(Wrapper.mc().field_71474_y.field_74368_y, 26, 26);
        this.movementKeys[2] = new Key(Wrapper.mc().field_71474_y.field_74370_x, 2, 26);
        this.movementKeys[3] = new Key(Wrapper.mc().field_71474_y.field_74366_z, 50, 26);
        this.mouseButtons[0] = new MouseButton(0, 2, 50);
        this.mouseButtons[1] = new MouseButton(1, 38, 50);
    }
    
    public void renderKeystrokes(final int x, final int y) {
        int textColor = 0;
        if (HackManager.getHack("HudNSDKeystrokes").isBooleanValue("TitleRainbow")) {
            textColor = Hud.SameColor;
        }
        else {
            textColor = new Color((int)(Object)HackManager.getHack("HudNSDKeystrokes").isNumberValue("TitleRed"), (int)(Object)HackManager.getHack("HudNSDKeystrokes").isNumberValue("TitleGreen"), (int)(Object)HackManager.getHack("HudNSDKeystrokes").isNumberValue("TitleBlue")).getRGB();
        }
        final boolean showingMouseButtons = HackManager.getHack("HudNSDKeystrokes").isBooleanValue("Mouse");
        final ScaledResolution res = new ScaledResolution(Wrapper.mc());
        final int width = 74;
        final int height = showingMouseButtons ? 74 : 50;
        if (x < 0) {
            FileManager.SetHud("Keystrokes", String.valueOf(0), String.valueOf(y));
        }
        else if (x > res.func_78326_a() - 74) {
            FileManager.SetHud("Keystrokes", String.valueOf(res.func_78326_a() - 74), String.valueOf(y));
        }
        if (y < 0) {
            FileManager.SetHud("Keystrokes", String.valueOf(x), String.valueOf(0));
        }
        else if (y > res.func_78328_b() - height) {
            FileManager.SetHud("Keystrokes", String.valueOf(x), String.valueOf(res.func_78328_b() - height));
        }
        this.drawMovementKeys(x, y, textColor);
        if (showingMouseButtons) {
            this.drawMouseButtons(x, y, textColor);
        }
    }
    
    private int getColor(final int index) {
        if (index == 6) {
            return Color.HSBtoRGB(System.currentTimeMillis() % 1000L / 1000.0f, 0.8f, 0.8f);
        }
        return KeystrokesRenderer.COLORS[index];
    }
    
    private void drawMovementKeys(final int x, final int y, final int textColor) {
        for (final Key key : this.movementKeys) {
            key.renderKey(x, y, textColor);
        }
    }
    
    private void drawMouseButtons(final int x, final int y, final int textColor) {
        for (final MouseButton button : this.mouseButtons) {
            button.renderMouseButton(x, y, textColor);
        }
    }
    
    static {
        COLORS = new int[] { 16777215, 16711680, 65280, 255, 16776960, 11141290 };
    }
}
