package Space.hack.hacks.Visual;

import net.minecraft.util.*;
import Space.hack.*;
import Space.value.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import net.minecraftforge.client.event.*;
import java.util.*;
import Space.utils.*;

public class Xray extends Hack
{
    private Timer t;
    private List<BlockPos> ren;
    public NumberValue Range;
    public BooleanValue Iron;
    public BooleanValue Gold;
    public BooleanValue Diamond;
    public BooleanValue Emerald;
    public BooleanValue Lapis;
    public BooleanValue Redstone;
    public BooleanValue Coal;
    public BooleanValue Spawner;
    
    public Xray() {
        super("Xray", HackCategory.Visual, false);
        this.Range = new NumberValue("Range", 20.0, 5.0, 50.0);
        this.Iron = new BooleanValue("Iron", Boolean.valueOf(true));
        this.Gold = new BooleanValue("Gold", Boolean.valueOf(true));
        this.Diamond = new BooleanValue("Diamond", Boolean.valueOf(true));
        this.Emerald = new BooleanValue("Emerald", Boolean.valueOf(true));
        this.Lapis = new BooleanValue("Lapis", Boolean.valueOf(true));
        this.Redstone = new BooleanValue("Redstone", Boolean.valueOf(true));
        this.Coal = new BooleanValue("Coal", Boolean.valueOf(true));
        this.Spawner = new BooleanValue("Spawner", Boolean.valueOf(true));
        this.addValue(this.Range, this.Iron, this.Gold, this.Diamond, this.Emerald, this.Lapis, this.Redstone, this.Coal, this.Spawner);
    }
    
    @Override
    public void onEnable() {
        this.ren = new ArrayList<BlockPos>();
        (this.t = new Timer()).scheduleAtFixedRate(this.t(), 0L, 200L);
    }
    
    @Override
    public void onDisable() {
        if (this.t != null) {
            this.t.cancel();
            this.t.purge();
            this.t = null;
        }
    }
    
    private TimerTask t() {
        return new TimerTask() {
            @Override
            public void run() {
                Xray.this.ren.clear();
                int y;
                for (int ra = y = (int)(Object)Xray.this.Range.getValue(); y >= -ra; --y) {
                    for (int x = -ra; x <= ra; ++x) {
                        for (int z = -ra; z <= ra; ++z) {
                            if (Utils.isPlayerInGame()) {
                                final BlockPos p = new BlockPos(Wrapper.player().field_70165_t + x, Wrapper.player().field_70163_u + y, Wrapper.player().field_70161_v + z);
                                final Block bl = Wrapper.world().func_180495_p(p).func_177230_c();
                                if ((Xray.this.Iron.getValue() && bl.equals(Blocks.field_150366_p)) || (Xray.this.Gold.getValue() && bl.equals(Blocks.field_150352_o)) || (Xray.this.Diamond.getValue() && bl.equals(Blocks.field_150482_ag)) || (Xray.this.Emerald.getValue() && bl.equals(Blocks.field_150412_bA)) || (Xray.this.Lapis.getValue() && bl.equals(Blocks.field_150369_x)) || (Xray.this.Redstone.getValue() && bl.equals(Blocks.field_150450_ax)) || (Xray.this.Coal.getValue() && bl.equals(Blocks.field_150365_q)) || (Xray.this.Spawner.getValue() && bl.equals(Blocks.field_150474_ac))) {
                                    Xray.this.ren.add(p);
                                }
                            }
                        }
                    }
                }
            }
        };
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (Utils.isPlayerInGame() && !this.ren.isEmpty()) {
            final List<BlockPos> tRen = new ArrayList<BlockPos>(this.ren);
            for (final BlockPos p : tRen) {
                this.dr(p);
            }
        }
        super.onRenderWorldLast(event);
    }
    
    private void dr(final BlockPos p) {
        final int[] rgb = this.c(Wrapper.world().func_180495_p(p).func_177230_c());
        if (rgb[0] + rgb[1] + rgb[2] != 0) {
            RenderUtils.drawBlockESP(p, rgb[0], rgb[1], rgb[2]);
        }
    }
    
    private int[] c(final Block b) {
        int red = 0;
        int green = 0;
        int blue = 0;
        if (b.equals(Blocks.field_150366_p)) {
            red = 255;
            green = 255;
            blue = 255;
        }
        else if (b.equals(Blocks.field_150352_o)) {
            red = 255;
            green = 255;
        }
        else if (b.equals(Blocks.field_150482_ag)) {
            green = 220;
            blue = 255;
        }
        else if (b.equals(Blocks.field_150412_bA)) {
            red = 35;
            green = 255;
        }
        else if (b.equals(Blocks.field_150369_x)) {
            green = 50;
            blue = 255;
        }
        else if (b.equals(Blocks.field_150450_ax)) {
            red = 255;
        }
        else if (b.equals(Blocks.field_150474_ac)) {
            red = 30;
            blue = 135;
        }
        return new int[] { red, green, blue };
    }
}
