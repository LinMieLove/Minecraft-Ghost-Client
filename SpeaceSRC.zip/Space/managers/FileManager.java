package Space.managers;

import Space.*;
import Space.hack.hacks.Visual.*;
import Space.hack.*;
import java.util.*;
import java.io.*;
import java.util.regex.*;
import Space.value.*;
import com.google.gson.*;

public class FileManager
{
    private static Gson gsonPretty;
    private static JsonParser jsonParser;
    private static File HACKS;
    private static File HUD;
    private static JsonObject Hudjson;
    
    public FileManager() {
        FileManager.HACKS = new File("C:\\Space\\Config\\Space." + Core.version);
        FileManager.HUD = new File("C:\\Space\\Config\\Hud." + Core.version);
        if (!FileManager.HACKS.exists()) {
            saveHacks(true);
        }
        else {
            loadHacks();
        }
        if (FileManager.HUD.exists()) {
            ExistsHud();
        }
        else {
            AddHud(String.valueOf(1.0), String.valueOf(2.0), "ArrayList");
            saveHud();
            ExistsHud();
        }
    }
    
    public static void ExistsHud() {
        final Hack hack = HackManager.getHack("Hud");
        Hud.modexy.clear();
        for (final Value value : hack.getValues()) {
            if (value instanceof BooleanValue) {
                loadHud(value.getName());
                Hud.modexy.add("[Name:\"" + value.getName() + "\" X:\"" + Hudxy("X") + "\" Y:\"" + Hudxy("Y") + "\"]");
            }
        }
    }
    
    public static void SetHud(final String name, final String x, final String y) {
        for (int i = 0; i < Hud.modexy.size(); ++i) {
            final String line = Hud.modexy.get(i);
            if (line.contains("[Name:\"" + name + "\"")) {
                final String updatedLine = "[Name:\"" + name + "\" X:\"" + x + "\" Y:\"" + y + "\"]";
                Hud.modexy.set(i, updatedLine);
                return;
            }
        }
    }
    
    public static void AddHud(final String x, final String y, final String name) {
        final String updatedLine = "[Name:\"" + name + "\" X:\"" + x + "\" Y:\"" + y + "\"]";
        Hud.modexy.add(updatedLine);
    }
    
    public static void loadHud(final String name) {
        try {
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(FileManager.HUD));
            final JsonObject jsonObject = (JsonObject)FileManager.jsonParser.parse((Reader)bufferedReader);
            bufferedReader.close();
            for (final Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                if (entry.getKey().equals(name)) {
                    FileManager.Hudjson = (JsonObject)entry.getValue();
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public static double Hudxy(final String xy) {
        if (xy.equals("x") || xy.equals("X")) {
            return FileManager.Hudjson.get("X").getAsDouble();
        }
        if (xy.equals("y") || xy.equals("Y")) {
            return FileManager.Hudjson.get("Y").getAsDouble();
        }
        return 0.0;
    }
    
    public static void saveHud() {
        try {
            final JsonObject json = new JsonObject();
            for (int i = 0; i < Hud.modexy.size(); ++i) {
                final String line = Hud.modexy.get(i);
                final Pattern pattern = Pattern.compile("\\[Name:\"([^\"]+)\" X:\"(\\d+(\\.\\d+)?)\" Y:\"(\\d+(\\.\\d+)?)\"\\]");
                final Matcher matcher = pattern.matcher(line);
                if (!matcher.find()) {
                    return;
                }
                final String name = matcher.group(1);
                final String X = matcher.group(2);
                final String Y = matcher.group(4);
                final JsonObject jsonHack = new JsonObject();
                if (!X.equals("0") && !X.equals("1") && !X.equals("") && !X.equals(" ")) {
                    jsonHack.addProperty("X", X);
                }
                if (!Y.equals("0") && !Y.equals("1") && !X.equals("") && !X.equals(" ")) {
                    jsonHack.addProperty("Y", Y);
                }
                json.add(name, (JsonElement)jsonHack);
                final PrintWriter saveJson = new PrintWriter(new FileWriter(FileManager.HUD));
                saveJson.println(FileManager.gsonPretty.toJson((JsonElement)json));
                saveJson.close();
            }
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void loadHacks() {
        try {
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(FileManager.HACKS));
            final JsonObject jsonObject = (JsonObject)FileManager.jsonParser.parse((Reader)bufferedReader);
            bufferedReader.close();
            for (final Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                final Hack hack = HackManager.getHack(entry.getKey());
                if (hack == null) {
                    continue;
                }
                final JsonObject jsonObjectHack = (JsonObject)entry.getValue();
                hack.setKey(jsonObjectHack.get("KeyValuekey").getAsInt());
                if (hack.Default()) {
                    hack.setToggled100(hack.Default_Toggled());
                }
                else {
                    hack.setToggled100(jsonObjectHack.get("KeyValuetoggled").getAsBoolean());
                }
                if (hack.getValues().isEmpty()) {
                    continue;
                }
                for (final Value value : hack.getValues()) {
                    if (value instanceof BooleanValue) {
                        value.setValue(jsonObjectHack.get("BooleanValue" + value.getName()).getAsBoolean());
                    }
                    if (value instanceof NumberValue) {
                        value.setValue(jsonObjectHack.get("NumberValue" + value.getName()).getAsDouble());
                    }
                    if (value instanceof ModeValue) {
                        final ModeValue modeValue = (ModeValue)value;
                        for (final Mode mode : modeValue.getModes()) {
                            mode.setToggled(jsonObjectHack.get("ModeValue" + mode.getName()).getAsBoolean());
                        }
                    }
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public static void saveHacks(final boolean send) {
        try {
            final JsonObject json = new JsonObject();
            for (final Hack hack : HackManager.getHacks()) {
                final JsonObject jsonHack = new JsonObject();
                if (send) {
                    jsonHack.addProperty("KeyValuetoggled", hack.isToggled2());
                }
                else {
                    jsonHack.addProperty("KeyValuetoggled", hack.isToggled());
                }
                jsonHack.addProperty("KeyValuekey", (Number)hack.getKey());
                if (!hack.getValues().isEmpty()) {
                    for (final Value value : hack.getValues()) {
                        if (value instanceof BooleanValue) {
                            jsonHack.addProperty("BooleanValue" + value.getName(), (Boolean)value.getValue());
                        }
                        if (value instanceof NumberValue) {
                            jsonHack.addProperty("NumberValue" + value.getName(), (Number)value.getValue());
                        }
                        if (value instanceof ModeValue) {
                            final ModeValue modeValue = (ModeValue)value;
                            for (final Mode mode : modeValue.getModes()) {
                                jsonHack.addProperty("ModeValue" + mode.getName(), mode.isToggled());
                            }
                        }
                    }
                }
                json.add(hack.getName(), (JsonElement)jsonHack);
            }
            final PrintWriter saveJson = new PrintWriter(new FileWriter(FileManager.HACKS));
            saveJson.println(FileManager.gsonPretty.toJson((JsonElement)json));
            saveJson.close();
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    static {
        FileManager.gsonPretty = new GsonBuilder().setPrettyPrinting().create();
        FileManager.jsonParser = new JsonParser();
        FileManager.HACKS = null;
    }
}
