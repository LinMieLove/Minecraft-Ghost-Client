package Space.managers;

import Space.*;
import Space.hack.hacks.Another.*;
import Space.hack.hacks.Combat.*;
import Space.hack.hacks.Player.*;
import Space.hack.hacks.Movement.*;
import Space.hack.hacks.Visual.*;
import Space.hack.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.client.event.*;
import java.util.*;
import Space.utils.*;
import Space.value.*;

public class HackManager
{
    public static ArrayList<Hack> hacks;
    public static String OK;
    private static String Yes;
    private static String Executing;
    public static String Feature;
    
    public HackManager() {
        Disposal.Send60("Allow addHacks");
    }
    
    public static void addHacks() {
        addHack(new AntiBot());
        addHack(new Targets());
        addHack(new Teams());
        addHack(new SuperKnockback());
        addHack(new AutoClicker());
        addHack(new InfiniteAura());
        addHack(new AuraAim());
        addHack(new LeftClicker());
        addHack(new LeftAim());
        addHack(new KillAura());
        addHack(new Criticals());
        addHack(new Velocity());
        addHack(new ChatTranslator());
        addHack(new AutoTool());
        addHack(new FastPlace());
        addHack(new Eagle());
        addHack(new NoFall());
        addHack(new LongJump());
        addHack(new Jetpack());
        addHack(new Speed());
        addHack(new Sprint());
        addHack(new Flight());
        addHack(new TnTFly());
        addHack(new ArmorHUD());
        addHack(new ChestESP());
        addHack(new EnemyInfo());
        addHack(new Hud());
        addHack(new HudNSDArrayList());
        addHack(new HudNSDKeystrokes());
        addHack(new Xray());
        addHack(new Fov());
        addHack(new NightVision());
        addHack(new Profiler());
        addHack(new Tracers());
        addHack(new NoBob());
        addHack(new End());
    }
    
    public static ArrayList<Hack> getHacks() {
        return HackManager.hacks;
    }
    
    public static void addHack(final Hack hack) {
        if (!HackManager.Executing.equals(hack.getName()) && !HackManager.Executing.equals("")) {
            return;
        }
        if (HackManager.OK.contains(hack.getName()) && !HackManager.Yes.contains(hack.getName())) {
            HackManager.Yes += hack.getName();
            HackManager.Executing = "";
            HackManager.hacks.add(hack);
        }
        else {
            if (hack.getName().equals("End")) {
                HackManager.Feature = "ALL Ok";
            }
            else {
                HackManager.Feature = "Feature initialization " + hack.getName() + "-" + hack.getCategory();
            }
            HackManager.Executing = hack.getName();
        }
    }
    
    public static Hack getHack(final String name) {
        Hack hack = null;
        for (final Hack h : getHacks()) {
            if (h.getName().equals(name)) {
                hack = h;
            }
        }
        return hack;
    }
    
    public static void onClientTick(final TickEvent.ClientTickEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onClientTick(event);
            }
        }
    }
    
    public static void onAttackEntity(final AttackEntityEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onAttackEntity(event);
            }
        }
    }
    
    public static void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onLivingUpdate(event);
            }
        }
    }
    
    public static void onPlayerMove(final LivingEvent.LivingUpdateEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onPlayerMove(event);
            }
        }
    }
    
    public static void onLeftClickBlock(final PlayerInteractEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onLeftClickBlock(event);
            }
        }
    }
    
    public static void onCameraSetup(final EntityViewRenderEvent.CameraSetup event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onCameraSetup(event);
            }
        }
    }
    
    public static void onRightClickItem(final PlayerInteractEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRightClickItem(event);
            }
        }
    }
    
    public static void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRenderGameOverlay(event);
            }
        }
    }
    
    public static void onMouse(final MouseEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onMouse(event);
            }
        }
    }
    
    public static void onInputUpdate(final TickEvent.PlayerTickEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onInputUpdate(event);
            }
        }
    }
    
    public static void onRenderWorldLast(final RenderWorldLastEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRenderWorldLast(event);
            }
        }
    }
    
    public static void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onPlayerTick(event);
            }
        }
    }
    
    public static void onRender3D(final RenderBlockOverlayEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRender3D(event);
            }
        }
    }
    
    public static List<Hack> getSortedHacks() {
        final List<Hack> list = new ArrayList<Hack>();
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                if (!hack.isShow()) {
                    continue;
                }
                list.add(hack);
            }
        }
        list.sort(new Comparator<Hack>() {
            @Override
            public int compare(final Hack h1, final Hack h2) {
                String s1 = h1.getRenderName();
                String s2 = h2.getRenderName();
                for (final Value value : h1.getValues()) {
                    if (value instanceof ModeValue) {
                        final ModeValue modeValue = (ModeValue)value;
                        if (!modeValue.getName().equals("Mode")) {
                            continue;
                        }
                        for (final Mode mode : modeValue.getModes()) {
                            if (mode.isToggled()) {
                                s1 = s1 + " " + mode.getName();
                            }
                        }
                    }
                }
                for (final Value value : h2.getValues()) {
                    if (value instanceof ModeValue) {
                        final ModeValue modeValue = (ModeValue)value;
                        if (!modeValue.getName().equals("Mode")) {
                            continue;
                        }
                        for (final Mode mode : modeValue.getModes()) {
                            if (mode.isToggled()) {
                                s2 = s2 + " " + mode.getName();
                            }
                        }
                    }
                }
                final int cmp = Wrapper.fontRenderer().func_78256_a(s2) - Wrapper.fontRenderer().func_78256_a(s1);
                return (cmp != 0) ? cmp : s2.compareTo(s1);
            }
        });
        return list;
    }
    
    static {
        HackManager.hacks = new ArrayList<Hack>();
        HackManager.OK = "";
        HackManager.Yes = "";
        HackManager.Executing = "";
        HackManager.Feature = "";
    }
}
