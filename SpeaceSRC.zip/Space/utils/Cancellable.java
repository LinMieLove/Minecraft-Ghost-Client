package Space.utils;

public interface Cancellable
{
    boolean isCancelled();
    
    void setCancelled(final boolean p0);
}
