package Space.utils;

import Space.*;
import io.netty.channel.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

public class Connection extends ChannelDuplexHandler
{
    private EventsHandler eventHandler;
    
    public Connection(final EventsHandler eventHandler) {
        this.eventHandler = eventHandler;
        try {
            final ChannelPipeline pipeline = Wrapper.mc().func_147114_u().func_147298_b().channel().pipeline();
            pipeline.addBefore("packet_handler", "PacketHandler", (ChannelHandler)this);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public void channelRead(final ChannelHandlerContext ctx, final Object packet) throws Exception {
        if (((Packet)packet) instanceof C03PacketPlayer.C04PacketPlayerPosition) {
            final C03PacketPlayer.C04PacketPlayerPosition packetPlayer = (C03PacketPlayer.C04PacketPlayerPosition)packet;
            final double x = ReflectionHelper.getPrivateValue((Class<? super C03PacketPlayer.C04PacketPlayerPosition>)C03PacketPlayer.class, packetPlayer, "x", "x");
            final double y = ReflectionHelper.getPrivateValue((Class<? super C03PacketPlayer.C04PacketPlayerPosition>)C03PacketPlayer.class, packetPlayer, "y", "y");
            final double z = ReflectionHelper.getPrivateValue((Class<? super C03PacketPlayer.C04PacketPlayerPosition>)C03PacketPlayer.class, packetPlayer, "z", "z");
            final float yaw = ReflectionHelper.getPrivateValue((Class<? super C03PacketPlayer.C04PacketPlayerPosition>)C03PacketPlayer.class, packetPlayer, "yaw", "yaw");
            final float pitch = ReflectionHelper.getPrivateValue((Class<? super C03PacketPlayer.C04PacketPlayerPosition>)C03PacketPlayer.class, packetPlayer, "pitch", "pitch");
            ReflectionHelper.getPrivateValue((Class<? super C03PacketPlayer.C04PacketPlayerPosition>)C03PacketPlayer.class, packetPlayer, "onGround", "onGround");
        }
        if (!this.eventHandler.onPacket(packet, Side.IN)) {
            return;
        }
        super.channelRead(ctx, packet);
    }
    
    public enum Side
    {
        IN, 
        OUT;
    }
}
