package Space.utils;

public interface Event
{
}
