package Space.utils;

import java.util.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.entity.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.client.gui.*;
import net.minecraft.util.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.potion.*;
import com.sun.javafx.geom.*;

public class Utils
{
    private static final Random RANDOM;
    public static float[] rotationsToBlock;
    
    public static boolean nullCheck() {
        return Wrapper.player() == null || Wrapper.world() == null;
    }
    
    public static int random(final int min, final int max) {
        return Utils.RANDOM.nextInt(max - min) + min;
    }
    
    public static List<Entity> getEntityList() {
        return (List<Entity>)Wrapper.world().func_72910_y();
    }
    
    public static float getPitch(final Entity entity) {
        double y = entity.field_70163_u - Wrapper.player().field_70163_u;
        y /= Wrapper.player().func_70068_e(entity);
        double pitch = Math.asin(y) * 57.29577951308232;
        pitch = -pitch;
        return (float)pitch;
    }
    
    public static double[] teleportToPosition(final double[] startPosition, final double[] endPosition, final double setOffset, final double slack, final boolean extendOffset, final boolean onGround) {
        boolean wasSneaking = false;
        if (Wrapper.player().func_70093_af()) {
            wasSneaking = true;
        }
        double startX = startPosition[0];
        double startY = startPosition[1];
        double startZ = startPosition[2];
        final double endX = endPosition[0];
        final double endY = endPosition[1];
        final double endZ = endPosition[2];
        double distance = Math.abs(startX - startY) + Math.abs(startY - endY) + Math.abs(startZ - endZ);
        int count = 0;
        while (distance > slack) {
            distance = Math.abs(startX - endX) + Math.abs(startY - endY) + Math.abs(startZ - endZ);
            if (count > 120) {
                break;
            }
            final double offset = (extendOffset && (count & 0x1) == 0x0) ? (setOffset + 0.15) : setOffset;
            final double diffX = startX - endX;
            final double diffY = startY - endY;
            final double diffZ = startZ - endZ;
            if (diffX < 0.0) {
                if (Math.abs(diffX) > offset) {
                    startX += offset;
                }
                else {
                    startX += Math.abs(diffX);
                }
            }
            if (diffX > 0.0) {
                if (Math.abs(diffX) > offset) {
                    startX -= offset;
                }
                else {
                    startX -= Math.abs(diffX);
                }
            }
            if (diffY < 0.0) {
                if (Math.abs(diffY) > offset) {
                    startY += offset;
                }
                else {
                    startY += Math.abs(diffY);
                }
            }
            if (diffY > 0.0) {
                if (Math.abs(diffY) > offset) {
                    startY -= offset;
                }
                else {
                    startY -= Math.abs(diffY);
                }
            }
            if (diffZ < 0.0) {
                if (Math.abs(diffZ) > offset) {
                    startZ += offset;
                }
                else {
                    startZ += Math.abs(diffZ);
                }
            }
            if (diffZ > 0.0) {
                if (Math.abs(diffZ) > offset) {
                    startZ -= offset;
                }
                else {
                    startZ -= Math.abs(diffZ);
                }
            }
            if (wasSneaking) {
                Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.STOP_SNEAKING));
            }
            Wrapper.sendPacket((Packet)new C03PacketPlayer.C04PacketPlayerPosition(startX, startY, startZ, onGround));
            ++count;
        }
        if (wasSneaking) {
            Wrapper.sendPacket((Packet)new C0BPacketEntityAction((Entity)Wrapper.player(), C0BPacketEntityAction.Action.START_SNEAKING));
        }
        return new double[] { startX, startY, startZ };
    }
    
    public static boolean isNullOrEmptyStack(final ItemStack stack) {
        return stack == null;
    }
    
    public static void windowClick(final int windowId, final int slotId, final int mouseButton, final int type) {
        Wrapper.controller().func_78753_a(windowId, slotId, mouseButton, type, (EntityPlayer)Wrapper.player());
    }
    
    public static String getPlayerName(final EntityPlayer player) {
        return (player.func_146103_bH() != null) ? player.func_146103_bH().getName() : player.func_70005_c_();
    }
    
    public static float getYaw(final Entity entity) {
        final double x = entity.field_70165_t - Wrapper.player().field_70165_t;
        final double z = entity.field_70161_v - Wrapper.player().field_70161_v;
        double yaw = Math.atan2(x, z) * 57.29577951308232;
        yaw = -yaw;
        return (float)yaw;
    }
    
    public static void swing() {
        final EntityPlayerSP p = Wrapper.player();
        final int armSwingEnd = p.func_70644_a(Potion.field_76422_e) ? (6 - (1 + p.func_70660_b(Potion.field_76422_e).func_76458_c())) : (p.func_70644_a(Potion.field_76419_f) ? (6 + (1 + p.func_70660_b(Potion.field_76419_f).func_76458_c()) * 2) : 6);
        if (!p.field_82175_bq || p.field_110158_av >= armSwingEnd / 2 || p.field_110158_av < 0) {
            p.field_110158_av = -1;
            p.field_82175_bq = true;
        }
    }
    
    public static float[] getRotations(final Entity e) {
        final double deltaX = e.field_70165_t + (e.field_70165_t - e.field_70142_S) - Wrapper.player().field_70165_t;
        final double deltaZ = e.field_70161_v + (e.field_70161_v - e.field_70136_U) - Wrapper.player().field_70161_v;
        final double deltaY = e.field_70163_u - 3.5 + e.func_70047_e() - Wrapper.player().field_70163_u + Wrapper.player().func_70047_e();
        final double distance = Math.sqrt(Math.pow(deltaX, 2.0) + Math.pow(deltaZ, 2.0));
        float yaw = (float)Math.toDegrees(-Math.atan(deltaX / deltaZ));
        final float pitch = (float)(-Math.toDegrees(Math.atan(deltaY / distance)));
        if (deltaX < 0.0 && deltaZ < 0.0) {
            yaw = (float)(90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
        }
        else if (deltaX > 0.0 && deltaZ < 0.0) {
            yaw = (float)(-90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
        }
        return new float[] { yaw, pitch };
    }
    
    public static int getPlayerArmorColor(final EntityPlayer player, final ItemStack stack) {
        if (player == null || stack == null || stack.func_77973_b() == null || !(stack.func_77973_b() instanceof ItemArmor)) {
            return -1;
        }
        final ItemArmor itemArmor = (ItemArmor)stack.func_77973_b();
        if (itemArmor == null || itemArmor.func_82812_d() != ItemArmor.ArmorMaterial.LEATHER) {
            return -1;
        }
        return itemArmor.func_82814_b(stack);
    }
    
    public static int getDistanceFromMouse(final EntityLivingBase entity) {
        final float[] neededRotations = getRotationsNeeded((Entity)entity);
        if (neededRotations != null) {
            final float neededYaw = Wrapper.player().field_70177_z - neededRotations[0];
            final float neededPitch = Wrapper.player().field_70125_A - neededRotations[1];
            final float distanceFromMouse = (float)Math.sqrt(neededYaw * neededYaw + neededPitch * neededPitch * 2.0f);
            return (int)distanceFromMouse;
        }
        return -1;
    }
    
    public static boolean isMoving() {
        return Wrapper.player() != null && (Wrapper.player().field_71158_b.field_78900_b != 0.0f || Wrapper.player().field_71158_b.field_78902_a != 0.0f);
    }
    
    public static boolean checkEnemyColor(final EntityPlayer enemy) {
        final int colorEnemy0 = getPlayerArmorColor(enemy, enemy.field_71071_by.func_70440_f(0));
        final int colorEnemy2 = getPlayerArmorColor(enemy, enemy.field_71071_by.func_70440_f(1));
        final int colorEnemy3 = getPlayerArmorColor(enemy, enemy.field_71071_by.func_70440_f(2));
        final int colorEnemy4 = getPlayerArmorColor(enemy, enemy.field_71071_by.func_70440_f(3));
        final int colorPlayer0 = getPlayerArmorColor((EntityPlayer)Wrapper.player(), Wrapper.player().field_71071_by.func_70440_f(0));
        final int colorPlayer2 = getPlayerArmorColor((EntityPlayer)Wrapper.player(), Wrapper.player().field_71071_by.func_70440_f(1));
        final int colorPlayer3 = getPlayerArmorColor((EntityPlayer)Wrapper.player(), Wrapper.player().field_71071_by.func_70440_f(2));
        final int colorPlayer4 = getPlayerArmorColor((EntityPlayer)Wrapper.player(), Wrapper.player().field_71071_by.func_70440_f(3));
        return (colorEnemy0 != colorPlayer0 || colorPlayer0 == -1 || colorEnemy0 == 1) && (colorEnemy2 != colorPlayer2 || colorPlayer2 == -1 || colorEnemy2 == 1) && (colorEnemy3 != colorPlayer3 || colorPlayer3 == -1 || colorEnemy3 == 1) && (colorEnemy4 != colorPlayer4 || colorPlayer4 == -1 || colorEnemy4 == 1);
    }
    
    public static boolean checkEnemyNameColor(final EntityLivingBase entity) {
        final String name = entity.func_145748_c_().func_150254_d();
        return !getEntityNameColor((EntityLivingBase)Wrapper.player()).equals(getEntityNameColor(entity));
    }
    
    public static boolean screenCheck() {
        return !(Wrapper.mc().field_71462_r instanceof GuiContainer) && !(Wrapper.mc().field_71462_r instanceof GuiChat) && !(Wrapper.mc().field_71462_r instanceof GuiScreen);
    }
    
    public static String getEntityNameColor(final EntityLivingBase entity) {
        final String name = entity.func_145748_c_().func_150254_d();
        return "null";
    }
    
    public static float[] getRotationsNeeded(final Entity entity) {
        if (entity == null) {
            return null;
        }
        final double diffX = entity.field_70165_t - Wrapper.player().field_70165_t;
        final double diffZ = entity.field_70161_v - Wrapper.player().field_70161_v;
        double diffY;
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            diffY = entityLivingBase.field_70163_u + entityLivingBase.func_70047_e() - (Wrapper.player().field_70163_u + Wrapper.player().func_70047_e());
        }
        else {
            diffY = (entity.func_174813_aQ().field_72338_b + entity.func_174813_aQ().field_72337_e) / 2.0 - (Wrapper.player().field_70163_u + Wrapper.player().func_70047_e());
        }
        final double dist = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / 3.141592653589793));
        return new float[] { Wrapper.player().field_70177_z + MathHelper.func_76142_g(yaw - Wrapper.player().field_70177_z), Wrapper.player().field_70125_A + MathHelper.func_76142_g(pitch - Wrapper.player().field_70125_A) };
    }
    
    public static float getDirection() {
        float var1 = Wrapper.player().field_70177_z;
        if (Wrapper.player().field_70701_bs < 0.0f) {
            var1 += 180.0f;
        }
        float forward = 1.0f;
        if (Wrapper.player().field_70701_bs < 0.0f) {
            forward = -0.5f;
        }
        else if (Wrapper.player().field_70701_bs > 0.0f) {
            forward = 0.5f;
        }
        if (Wrapper.player().field_70702_br > 0.0f) {
            var1 -= 90.0f * forward;
        }
        if (Wrapper.player().field_70702_br < 0.0f) {
            var1 += 90.0f * forward;
        }
        var1 *= 0.017453292f;
        return var1;
    }
    
    public static String getRemoteIp() {
        String serverIp = "Singleplayer";
        if (Wrapper.world().field_72995_K) {
            final ServerData serverData = Wrapper.mc().func_147104_D();
            if (serverData != null) {
                serverIp = Wrapper.mc().func_147104_D().field_78845_b;
            }
        }
        return serverIp;
    }
    
    public static void addEffect(final int id, final int duration, final int amplifier) {
        final Potion potion = getPotionById(id);
        if (potion != null) {
            Wrapper.player().func_70690_d(new PotionEffect(id, duration, amplifier));
        }
    }
    
    public static void removeEffect(final int id) {
        final Potion potion = getPotionById(id);
        if (potion != null) {
            Wrapper.player().func_82170_o(potion.func_76396_c());
        }
    }
    
    private static Potion getPotionById(final int id) {
        for (final Potion potion : Potion.field_76425_a) {
            if (potion != null && potion.func_76396_c() == id) {
                return potion;
            }
        }
        return null;
    }
    
    public static Vec3d getEyesPos() {
        return new Vec3d(Wrapper.player().field_70165_t, Wrapper.player().field_70163_u + Wrapper.player().func_70047_e(), Wrapper.player().field_70161_v);
    }
    
    public static boolean isPlayerInGame() {
        return Wrapper.player() != null && Wrapper.world() != null;
    }
    
    public static boolean isPlayerInContainer() {
        return Wrapper.mc().field_71462_r instanceof GuiContainer;
    }
    
    public static void attack(final Entity entity) {
        Wrapper.controller().func_78764_a((EntityPlayer)Wrapper.player(), entity);
    }
    
    public static void aim(final Entity entity, final float pitchOffset, final boolean silent) {
        if (entity != null) {
            final float[] t = getTargetRotations(entity);
            if (t != null) {
                final float yaw = t[0];
                final float pitch = t[1] + 4.0f + pitchOffset;
                if (!silent) {
                    Wrapper.player().field_70177_z = yaw;
                    Wrapper.player().field_70125_A = pitch;
                }
                else {
                    Wrapper.player().field_70759_as = yaw;
                }
            }
        }
    }
    
    public static float[] getTargetRotations(final Entity q) {
        if (q == null) {
            return null;
        }
        final double diffX = q.field_70165_t - Wrapper.player().field_70165_t;
        double diffY;
        if (q instanceof EntityLivingBase) {
            final EntityLivingBase en = (EntityLivingBase)q;
            diffY = en.field_70163_u + en.func_70047_e() * 0.9 - (Wrapper.player().field_70163_u + Wrapper.player().func_70047_e());
        }
        else {
            diffY = (q.func_174813_aQ().field_72338_b + q.func_174813_aQ().field_72337_e) / 2.0 - (Wrapper.player().field_70163_u + Wrapper.player().func_70047_e());
        }
        final double diffZ = q.field_70161_v - Wrapper.player().field_70161_v;
        final double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / 3.141592653589793));
        return new float[] { Wrapper.player().field_70177_z + wrapAngleTo180_float(yaw - Wrapper.player().field_70177_z), Wrapper.player().field_70125_A + wrapAngleTo180_float(pitch - Wrapper.player().field_70125_A) };
    }
    
    public static float wrapAngleTo180_float(float angle) {
        angle %= 360.0f;
        if (angle >= 180.0f) {
            angle -= 360.0f;
        }
        if (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }
    
    static {
        Utils.rotationsToBlock = null;
        RANDOM = new Random();
    }
}
