package Space.utils;

import Space.managers.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import Space.*;
import Space.hack.*;
import Space.hack.hacks.Another.*;

public class ValidUtils
{
    public static boolean isLowHealth(final EntityLivingBase entity, final EntityLivingBase entityPriority) {
        return entityPriority == null || entity.func_110143_aJ() < entityPriority.func_110143_aJ();
    }
    
    public static boolean isClosest(final EntityLivingBase entity, final EntityLivingBase entityPriority) {
        return entityPriority == null || Wrapper.player().func_70032_d((Entity)entity) < Wrapper.player().func_70032_d((Entity)entityPriority);
    }
    
    public static boolean isRange(final EntityLivingBase entity, final EntityLivingBase entityPriority) {
        return entityPriority == null || entity.func_70032_d((Entity)Wrapper.player()) < entityPriority.func_70032_d((Entity)Wrapper.player());
    }
    
    public static boolean isInAttackFOV(final EntityLivingBase entity, final int fov) {
        return Utils.getDistanceFromMouse(entity) <= fov;
    }
    
    public static boolean isInAttackRange(final EntityLivingBase entity, final float range) {
        return entity.func_70032_d((Entity)Wrapper.player()) <= range;
    }
    
    public static boolean isValidEntity(final EntityLivingBase e) {
        final Hack targets = HackManager.getHack("Targets");
        if (targets.isToggled()) {
            if (targets.isToggledValue("Players") && e instanceof EntityPlayer) {
                return !targets.isToggledValue("Sleeping") && e.func_70608_bn();
            }
            if (targets.isToggledValue("Mobs") && e instanceof EntityLiving) {
                return false;
            }
        }
        else {
            Disposal.SendX("If Targets is not turned on, you cannot select an attack target!");
        }
        return true;
    }
    
    public static boolean isTeam(final EntityLivingBase entity) {
        final Hack teams = HackManager.getHack("Teams");
        if (teams.isToggled() && entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)entity;
            if (teams.isToggledModeY("Base") && player.func_96124_cp() != null && Wrapper.player().func_96124_cp() != null && player.func_96124_cp().func_142054_a(Wrapper.player().func_96124_cp())) {
                return false;
            }
            if (teams.isToggledModeY("Armor") && !Utils.checkEnemyColor(player)) {
                return false;
            }
            if (teams.isToggledModeY("Name") && !Utils.checkEnemyNameColor((EntityLivingBase)player)) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isBooleanValue(final String Name, final String Mode) {
        final Hack hack = HackManager.getHack(Name);
        return hack.isToggled() && hack.isToggledModeY(Mode);
    }
    
    public static double isNumberValue(final String Name, final String Mode) {
        final Hack hack = HackManager.getHack(Name);
        if (hack.isToggled()) {
            return hack.isNumberValue(Mode);
        }
        return 0.0;
    }
    
    public static boolean isBot(final EntityLivingBase entity) {
        final Hack hack = HackManager.getHack("AntiBot");
        if (hack.isToggled() && entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)entity;
            return hack.isToggled() && AntiBot.isBot(player, hack);
        }
        return false;
    }
    
    public static boolean isInvisible(final EntityLivingBase entity) {
        final Hack targets = HackManager.getHack("Targets");
        return targets.isToggledValue("Invisibles") || !entity.func_82150_aj();
    }
    
    public static boolean isNoScreen() {
        return Utils.screenCheck();
    }
}
