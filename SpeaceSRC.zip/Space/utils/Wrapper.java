package Space.utils;

import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.entity.*;
import net.minecraft.network.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.multiplayer.*;

public class Wrapper
{
    public static Minecraft mc() {
        return Minecraft.func_71410_x();
    }
    
    public static FontRenderer fontRenderer() {
        return mc().field_71466_p;
    }
    
    public static EntityPlayerSP player() {
        return mc().field_71439_g;
    }
    
    public static WorldClient world() {
        return mc().field_71441_e;
    }
    
    public static void sendPacket(final Packet packet) {
        mc().func_147114_u().func_147297_a(packet);
    }
    
    public static InventoryPlayer inventory() {
        return player().field_71071_by;
    }
    
    public static PlayerControllerMP controller() {
        return mc().field_71442_b;
    }
}
