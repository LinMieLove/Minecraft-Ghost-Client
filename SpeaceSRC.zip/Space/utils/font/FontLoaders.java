package Space.utils.font;

import java.awt.*;
import java.io.*;

public abstract class FontLoaders
{
    public static CFontRenderer default18;
    public static CFontRenderer default29;
    public static CFontRenderer default14;
    public static CFontRenderer SFB17;
    
    private static Font getSFB(final int size) {
        Font font = new Font("default", 0, size);
        try {
            final File a = new File("C:\\Thanatos\\SF-UI-Display-Bold.otf");
            font = Font.createFont(0, a);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            font = new Font("default", 0, size);
        }
        return font;
    }
    
    public static CFontRenderer Default(final int size) {
        return new CFontRenderer(new Font("default", 0, size), true, true);
    }
    
    static {
        FontLoaders.default18 = new CFontRenderer(new Font("default", 0, 18), true, true);
        FontLoaders.default29 = new CFontRenderer(new Font("default", 0, 29), true, true);
        FontLoaders.default18 = new CFontRenderer(new Font("default", 0, 18), true, true);
        FontLoaders.default14 = new CFontRenderer(new Font("default", 0, 14), true, true);
        FontLoaders.SFB17 = new CFontRenderer(getSFB(17), true, true);
    }
}
