package Space.value;

public class BooleanValue extends Value<Boolean>
{
    public BooleanValue(final String name, final Boolean defaultValue) {
        super(name, defaultValue);
    }
}
